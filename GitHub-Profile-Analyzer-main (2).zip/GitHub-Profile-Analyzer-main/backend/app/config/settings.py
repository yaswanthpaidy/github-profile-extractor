"""
DevInsight AI - Enhanced Configuration Settings
Production-level configuration management
"""

from pydantic_settings import BaseSettings
from typing import Optional
from functools import lru_cache


class Settings(BaseSettings):
    """
    Application Settings with environment variable support
    """
    
    # ============ Project Settings ============
    PROJECT_NAME: str = "DevInsight AI"
    PROJECT_DESCRIPTION: str = "Advanced Developer Intelligence & Analytics Platform"
    VERSION: str = "1.0.0"
    DEBUG: bool = False
    ENVIRONMENT: str = "development"  # development, staging, production
    
    # ============ API Settings ============
    API_PREFIX: str = "/api/v1"
    API_TITLE: str = "DevInsight AI API"
    BACKEND_CORS_ORIGINS: list = [
        "http://localhost:3000",
        "http://localhost:8000",
        "http://localhost:5173",
    ]
    
    # ============ GitHub API ============
    GITHUB_API_URL: str = "https://api.github.com"
    GITHUB_TOKEN: Optional[str] = None
    GITHUB_API_TIMEOUT: int = 30
    
    # ============ Database ============
    DATABASE_URL: Optional[str] = "sqlite+aiosqlite:///./devinsight.db"
    DATABASE_ECHO: bool = False
    
    # ============ Cache (Redis) ============
    REDIS_URL: Optional[str] = "redis://localhost:6379/0"
    CACHE_TTL: int = 3600  # 1 hour
    
    # ============ Authentication ============
    SECRET_KEY: str = "your-secret-key-change-in-production"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    REFRESH_TOKEN_EXPIRE_DAYS: int = 7
    
    # ============ Rate Limiting ============
    RATE_LIMIT_ENABLED: bool = True
    RATE_LIMIT_REQUESTS: int = 100
    RATE_LIMIT_PERIOD: int = 3600  # 1 hour
    
    # ============ AI Services ============
    OPENAI_API_KEY: Optional[str] = None
    OPENAI_MODEL: str = "gpt-4-turbo"
    GEMINI_API_KEY: Optional[str] = None
    
    # ============ External APIs ============
    LEETCODE_API_URL: str = "https://leetcode.com/graphql"
    CODEFORCES_API_URL: str = "https://codeforces.com/api"
    HACKERRANK_API_KEY: Optional[str] = None
    
    # ============ Logging ============
    LOG_LEVEL: str = "INFO"
    LOG_FORMAT: str = "json"  # json, standard
    
    class Config:
        env_file = ".env"
        case_sensitive = True


@lru_cache()
def get_settings() -> Settings:
    """
    Get application settings (cached)
    """
    return Settings()


# Create singleton instance
settings = get_settings()
