"""
Database CRUD operations for DevInsight AI
"""

from datetime import datetime
from typing import Optional, Any, Dict, List
from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.models import User, AnalysisReport


async def get_user_by_email(session: AsyncSession, email: str) -> Optional[User]:
    query = select(User).where(User.email == email)
    result = await session.execute(query)
    return result.scalars().first()


async def get_user_by_username(session: AsyncSession, username: str) -> Optional[User]:
    query = select(User).where(User.username == username)
    result = await session.execute(query)
    return result.scalars().first()


async def get_user_by_id(session: AsyncSession, user_id: int) -> Optional[User]:
    query = select(User).where(User.id == user_id)
    result = await session.execute(query)
    return result.scalars().first()


async def create_user(session: AsyncSession, user_data: Dict[str, Any]) -> User:
    user = User(
        username=user_data["username"],
        email=user_data["email"],
        hashed_password=user_data["hashed_password"],
        name=user_data.get("name"),
        avatar_url=user_data.get("avatar_url"),
        is_active=True,
        created_at=datetime.utcnow(),
        updated_at=datetime.utcnow(),
    )
    session.add(user)
    await session.commit()
    await session.refresh(user)
    return user


async def update_user_password(session: AsyncSession, user_id: int, new_hashed_password: str) -> Optional[User]:
    query = update(User).where(User.id == user_id).values(
        hashed_password=new_hashed_password,
        updated_at=datetime.utcnow()
    ).execution_options(synchronize_session="fetch")
    await session.execute(query)
    await session.commit()
    return await get_user_by_id(session, user_id)


async def create_analysis_report(
    session: AsyncSession,
    user_id: int,
    github_username: str,
    analysis_data: Dict[str, Any],
) -> AnalysisReport:
    report = AnalysisReport(
        user_id=user_id,
        github_username=github_username,
        analysis_data=analysis_data,
        created_at=datetime.utcnow(),
        updated_at=datetime.utcnow(),
    )
    session.add(report)
    await session.commit()
    await session.refresh(report)
    return report


async def get_reports_by_user(session: AsyncSession, user_id: int) -> List[AnalysisReport]:
    query = select(AnalysisReport).where(AnalysisReport.user_id == user_id).order_by(AnalysisReport.created_at.desc())
    result = await session.execute(query)
    return result.scalars().all()


async def get_report_by_id(session: AsyncSession, report_id: int, user_id: Optional[int] = None) -> Optional[AnalysisReport]:
    query = select(AnalysisReport).where(AnalysisReport.id == report_id)
    if user_id is not None:
        query = query.where(AnalysisReport.user_id == user_id)
    result = await session.execute(query)
    return result.scalars().first()
