"""
DevInsight AI - Main FastAPI Application
Modern backend entrypoint for Developer Intelligence Platform
"""

import logging
from contextlib import asynccontextmanager
from fastapi import FastAPI, Request, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from slowapi import Limiter
from slowapi.errors import RateLimitExceeded
from slowapi.middleware import SlowAPIMiddleware
from slowapi.util import get_remote_address

from app.api.middleware.error_handler import error_handler_middleware
from app.api.routes import auth as auth_routes
from app.api.routes.analytics import router as analytics_router
from app.api.routes.reports import router as reports_router
from app.api.v1.health import router as health_router
from app.config.settings import settings
from app.database.session import init_db
from app.services.github_service import GitHubService


# Configure logging
logging.basicConfig(
    level=settings.LOG_LEVEL,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

limiter = Limiter(key_func=get_remote_address)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifecycle management"""
    logger.info(f"🚀 {settings.PROJECT_NAME} v{settings.VERSION} starting...")
    logger.info(f"Environment: {settings.ENVIRONMENT}")
    await init_db()
    logger.info("Database initialized")
    yield
    logger.info(f"🛑 {settings.PROJECT_NAME} shutting down...")


# Create FastAPI application
app = FastAPI(
    title=settings.PROJECT_NAME,
    description=settings.PROJECT_DESCRIPTION,
    version=settings.VERSION,
    lifespan=lifespan,
    docs_url="/api/docs",
    redoc_url="/api/redoc",
    openapi_url="/api/openapi.json"
)


# CORS Configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.BACKEND_CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Rate limiting middleware
app.add_middleware(SlowAPIMiddleware)
app.state.limiter = limiter

app.add_exception_handler(RateLimitExceeded, lambda request, exc: JSONResponse(
    status_code=429,
    content={
        "error": "Rate limit exceeded",
        "detail": str(exc),
        "status_code": 429
    }
))

app.add_exception_handler(Exception, lambda request, exc: error_handler_middleware(exc))

# Mount routers
app.include_router(auth_routes.router, prefix=settings.API_PREFIX)
app.include_router(analytics_router, prefix=settings.API_PREFIX)
app.include_router(reports_router, prefix=settings.API_PREFIX)
app.include_router(health_router, prefix=f"{settings.API_PREFIX}/health")


# Root Endpoints
@app.get("/", tags=["Root"])
async def root():
    """API Root Endpoint"""
    return {
        "project": settings.PROJECT_NAME,
        "version": settings.VERSION,
        "description": settings.PROJECT_DESCRIPTION,
        "docs_url": "/api/docs",
        "status": "🟢 Running"
    }


@app.get("/api/", tags=["Root"])
async def api_root():
    """API v1 Root Endpoint"""
    return {
        "name": settings.PROJECT_NAME,
        "version": settings.VERSION,
        "endpoints": {
            "analytics": f"{settings.API_PREFIX}/analytics/analyze",
            "career": f"{settings.API_PREFIX}/career/{{username}}",
            "health": f"{settings.API_PREFIX}/health/",
            "auth": f"{settings.API_PREFIX}/auth/"
        }
    }


@app.get("/profile/{username}", tags=["Compatibility"])
async def profile_summary(username: str):
    """Legacy compatibility route for direct profile data."""
    github = GitHubService()
    profile = await github.get_profile(username)
    if not profile:
        raise HTTPException(status_code=404, detail="GitHub user not found")

    return {
        "username": profile.get("login"),
        "name": profile.get("name"),
        "bio": profile.get("bio"),
        "avatar_url": profile.get("avatar_url"),
        "followers": profile.get("followers"),
        "following": profile.get("following"),
        "public_repos": profile.get("public_repos"),
        "profile_url": profile.get("html_url")
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=8000,
        reload=settings.DEBUG
    )
