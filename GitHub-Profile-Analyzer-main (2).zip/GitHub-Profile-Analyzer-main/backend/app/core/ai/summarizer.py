"""
AI Engine for Generating Developer Insights & Recommendations
Powered by OpenAI/Gemini APIs
"""

from typing import Dict, List, Any, Optional
import json


class AIEngine:
    """
    AI-Powered Intelligence Engine
    Generates insights, summaries, and recommendations
    """
    
    def __init__(self, openai_client=None, gemini_client=None):
        """
        Initialize AI Engine
        
        Args:
            openai_client: OpenAI API client
            gemini_client: Google Gemini API client
        """
        self.openai = openai_client
        self.gemini = gemini_client
    
    async def generate_developer_summary(
        self,
        profile: Dict[str, Any],
        repositories: List[Dict],
        metrics: Dict[str, Any]
    ) -> str:
        """
        Generate AI-powered developer summary
        
        Args:
            profile: GitHub profile data
            repositories: List of repositories
            metrics: Calculated metrics
            
        Returns:
            AI-generated summary text
        """
        if not self.openai:
            return self._generate_fallback_summary(profile, repositories, metrics)
        
        prompt = self._build_summary_prompt(profile, repositories, metrics)
        
        try:
            response = await self.openai.ChatCompletion.acreate(
                model="gpt-4-turbo",
                messages=[
                    {
                        "role": "system",
                        "content": "You are an expert technical recruiter analyzing developer profiles. Provide insightful, professional summaries."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                temperature=0.7,
                max_tokens=500
            )
            
            return response.choices[0].message.content
        except Exception as e:
            print(f"AI summary generation failed: {e}")
            return self._generate_fallback_summary(profile, repositories, metrics)
    
    async def generate_career_recommendations(
        self,
        profile: Dict[str, Any],
        metrics: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Generate AI-powered career recommendations
        
        Returns:
            Career recommendations and role predictions
        """
        if not self.openai:
            return self._generate_fallback_recommendations(profile, metrics)
        
        prompt = self._build_recommendations_prompt(profile, metrics)
        
        try:
            response = await self.openai.ChatCompletion.acreate(
                model="gpt-4-turbo",
                messages=[
                    {
                        "role": "system",
                        "content": "You are an expert career advisor for software engineers. Provide specific, actionable recommendations based on their GitHub profile and metrics."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                temperature=0.7,
                max_tokens=800
            )
            
            content = response.choices[0].message.content
            return self._parse_recommendations(content)
        except Exception as e:
            print(f"Recommendations generation failed: {e}")
            return self._generate_fallback_recommendations(profile, metrics)
    
    async def generate_strengths_and_weaknesses(
        self,
        profile: Dict[str, Any],
        repositories: List[Dict],
        metrics: Dict[str, Any]
    ) -> Dict[str, List[str]]:
        """
        Analyze and generate strengths and weaknesses
        
        Returns:
            Dictionary with strengths and weaknesses
        """
        if not self.openai:
            return self._generate_fallback_analysis(profile, metrics)
        
        prompt = self._build_analysis_prompt(profile, repositories, metrics)
        
        try:
            response = await self.openai.ChatCompletion.acreate(
                model="gpt-4-turbo",
                messages=[
                    {
                        "role": "system",
                        "content": "Analyze the developer profile and provide concrete, specific strengths and areas for improvement."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                temperature=0.7,
                max_tokens=600
            )
            
            content = response.choices[0].message.content
            return self._parse_strengths_weaknesses(content)
        except Exception as e:
            print(f"Analysis generation failed: {e}")
            return self._generate_fallback_analysis(profile, metrics)
    
    async def generate_improvement_suggestions(
        self,
        profile: Dict[str, Any],
        metrics: Dict[str, Any]
    ) -> List[str]:
        """
        Generate specific improvement suggestions
        
        Returns:
            List of actionable improvement suggestions
        """
        if not self.openai:
            return self._generate_fallback_suggestions(profile, metrics)
        
        prompt = f"""
        Based on this GitHub profile, provide 5 specific, actionable suggestions to improve their developer brand:
        
        Username: {profile.get('login')}
        Public Repos: {profile.get('public_repos')}
        Stars: {metrics.get('total_stargazers_count', 0)}
        Followers: {profile.get('followers')}
        Developer Score: {metrics.get('developer_score', 0)}
        
        Suggest concrete actions they can take.
        """
        
        try:
            response = await self.openai.ChatCompletion.acreate(
                model="gpt-4-turbo",
                messages=[
                    {
                        "role": "system",
                        "content": "Provide specific, actionable, and realistic suggestions."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                temperature=0.7,
                max_tokens=500
            )
            
            content = response.choices[0].message.content
            return self._parse_suggestions(content)
        except Exception as e:
            print(f"Suggestions generation failed: {e}")
            return self._generate_fallback_suggestions(profile, metrics)
    
    # ============ Helper Methods ============
    
    def _build_summary_prompt(self, profile, repositories, metrics) -> str:
        """Build prompt for summary generation"""
        top_repos = sorted(
            repositories,
            key=lambda x: x.get('stargazers_count', 0),
            reverse=True
        )[:5]
        
        return f"""
        Analyze this GitHub developer profile and provide a professional 2-3 paragraph summary:
        
        Profile:
        - Username: {profile.get('login')}
        - Name: {profile.get('name')}
        - Bio: {profile.get('bio', 'Not provided')}
        - Public Repos: {profile.get('public_repos')}
        - Followers: {profile.get('followers')}
        - Following: {profile.get('following')}
        - Developer Score: {metrics.get('developer_score', 0)}/100
        
        Top Repositories:
        {json.dumps([{
            'name': r.get('name'),
            'description': r.get('description'),
            'language': r.get('language'),
            'stars': r.get('stargazers_count')
        } for r in top_repos], indent=2)}
        
        Metrics:
        - Total Stars: {metrics.get('total_stargazers_count', 0)}
        - Total Forks: {metrics.get('total_forks_count', 0)}
        - Languages: {', '.join(metrics.get('languages', {}).keys())}
        
        Write a compelling, professional summary highlighting their key strengths and specialties.
        """
    
    def _build_recommendations_prompt(self, profile, metrics) -> str:
        """Build prompt for career recommendations"""
        return f"""
        Based on this developer's GitHub profile, provide career recommendations:
        
        Username: {profile.get('login')}
        Developer Score: {metrics.get('developer_score', 0)}/100
        Primary Languages: {', '.join(metrics.get('languages', {}).keys())}
        Public Repos: {profile.get('public_repos')}
        
        Recommend:
        1. 3-5 ideal roles/positions they should target
        2. Companies or industries that would value their profile
        3. Areas to focus on to reach the next level
        4. Estimated salary range (based on experience signals)
        """
    
    def _build_analysis_prompt(self, profile, repositories, metrics) -> str:
        """Build prompt for strengths/weaknesses analysis"""
        return f"""
        Analyze this developer and provide:
        
        STRENGTHS (5-7 specific strengths):
        - List concrete strengths based on their GitHub profile
        
        AREAS FOR IMPROVEMENT (5-7 areas):
        - List specific areas where they can improve
        
        Developer Profile:
        Username: {profile.get('login')}
        Score: {metrics.get('developer_score', 0)}/100
        Repos: {profile.get('public_repos')}
        Primary Languages: {', '.join(list(metrics.get('languages', {}).keys())[:3])}
        """
    
    def _parse_recommendations(self, content: str) -> Dict[str, Any]:
        """Parse recommendations from AI response"""
        return {
            'recommendation': content,
            'generated_at': None,
            'model': 'gpt-4-turbo'
        }
    
    def _parse_strengths_weaknesses(self, content: str) -> Dict[str, List[str]]:
        """Parse strengths and weaknesses from AI response"""
        lines = content.split('\n')
        strengths = []
        weaknesses = []
        
        current_section = None
        for line in lines:
            if 'strength' in line.lower():
                current_section = 'strengths'
            elif 'weakness' in line.lower() or 'improvement' in line.lower():
                current_section = 'weaknesses'
            elif line.strip().startswith('-') or line.strip().startswith('•'):
                item = line.strip()[1:].strip()
                if item and current_section == 'strengths':
                    strengths.append(item)
                elif item and current_section == 'weaknesses':
                    weaknesses.append(item)
        
        return {
            'strengths': strengths[:7] if strengths else self._generate_fallback_strengths(),
            'weaknesses': weaknesses[:7] if weaknesses else self._generate_fallback_weaknesses()
        }
    
    def _parse_suggestions(self, content: str) -> List[str]:
        """Parse improvement suggestions from AI response"""
        suggestions = []
        lines = content.split('\n')
        
        for line in lines:
            if line.strip().startswith('-') or line.strip().startswith('•') or line.strip()[0].isdigit():
                item = line.strip()
                if '-' in item or '•' in item:
                    item = item.split('-' if '-' in item else '•')[1].strip()
                elif item[0].isdigit():
                    item = item.split('.', 1)[1].strip() if '.' in item else item
                
                if item and len(item) > 10:
                    suggestions.append(item)
        
        return suggestions[:5]
    
    # ============ Fallback Methods ============
    
    def _generate_fallback_summary(self, profile, repositories, metrics) -> str:
        """Generate fallback summary without AI"""
        langs = ', '.join(list(metrics.get('languages', {}).keys())[:3])
        return f"""
        {profile.get('name', profile.get('login'))} is an active developer with {profile.get('public_repos')} public repositories and a developer score of {metrics.get('developer_score', 0)}/100.
        
        Primary technology areas include {langs}. With {profile.get('followers')} followers and {metrics.get('total_stargazers_count', 0)} total stars, they demonstrate strong engagement with the open-source community.
        
        Their contribution patterns and repository portfolio suggest expertise in building scalable software solutions.
        """
    
    def _generate_fallback_recommendations(self, profile, metrics) -> Dict:
        """Generate fallback recommendations without AI"""
        score = metrics.get('developer_score', 0)
        
        roles = []
        if score > 80:
            roles = ["Senior Software Engineer", "Tech Lead", "Solution Architect"]
        elif score > 60:
            roles = ["Full Stack Developer", "Backend Engineer", "DevOps Engineer"]
        else:
            roles = ["Software Engineer", "Junior Developer", "Full Stack Developer"]
        
        return {
            'recommendation': f"Based on profile strength, recommended roles: {', '.join(roles)}",
            'roles': roles
        }
    
    def _generate_fallback_analysis(self, profile, metrics) -> Dict:
        """Generate fallback analysis without AI"""
        return {
            'strengths': self._generate_fallback_strengths(),
            'weaknesses': self._generate_fallback_weaknesses()
        }
    
    def _generate_fallback_strengths(self) -> List[str]:
        return [
            "Active open-source contributor",
            "Diverse technology portfolio",
            "Consistent coding activity",
            "Community engagement",
            "Problem-solving focus"
        ]
    
    def _generate_fallback_weaknesses(self) -> List[str]:
        return [
            "Could improve documentation quality",
            "More consistent contributions help visibility",
            "Consider exploring emerging technologies",
            "Engage more with community discussions",
            "Build more impactful projects"
        ]
    
    def _generate_fallback_suggestions(self, profile, metrics) -> List[str]:
        return [
            "Improve README documentation for key projects",
            "Contribute to more popular open-source projects",
            "Share technical insights through blog posts or articles",
            "Engage more in code reviews and community discussions",
            "Build a portfolio project showcasing your strengths"
        ]
