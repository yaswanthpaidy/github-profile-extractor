"""
Core Analytics Engine - Developer Score & Metrics Calculator
Calculates comprehensive developer metrics and scoring
"""

from typing import Dict, List, Any, Optional
from dataclasses import dataclass
from datetime import datetime, timedelta
import math


@dataclass
class DeveloperMetrics:
    """Developer performance metrics"""
    total_repositories: int
    total_stars: int
    total_forks: int
    languages: Dict[str, int]
    total_contributions: int
    longest_streak: int
    average_commits_per_repo: float
    open_source_impact: float
    collaboration_score: float
    code_consistency: float


class AnalyticsEngine:
    """
    Advanced Analytics Engine for Developer Insights
    Provides comprehensive scoring and analytics
    """
    
    def __init__(self):
        """Initialize analytics engine"""
        self.max_score = 100
        self.contribution_weight = 0.25
        self.stars_weight = 0.20
        self.consistency_weight = 0.20
        self.diversity_weight = 0.15
        self.impact_weight = 0.20
    
    def calculate_developer_score(self, metrics: Dict[str, Any]) -> float:
        """
        Calculate comprehensive developer score (0-100)
        
        Args:
            metrics: Dictionary containing developer metrics
            
        Returns:
            Developer score between 0-100
        """
        scores = {
            'contribution': self._calculate_contribution_score(metrics),
            'impact': self._calculate_impact_score(metrics),
            'consistency': self._calculate_consistency_score(metrics),
            'diversity': self._calculate_diversity_score(metrics),
            'collaboration': self._calculate_collaboration_score(metrics),
        }
        
        total_score = (
            scores['contribution'] * self.contribution_weight +
            scores['impact'] * self.stars_weight +
            scores['consistency'] * self.consistency_weight +
            scores['diversity'] * self.diversity_weight +
            scores['collaboration'] * self.impact_weight
        )
        
        return min(self.max_score, max(0, total_score))
    
    def _calculate_contribution_score(self, metrics: Dict[str, Any]) -> float:
        """Calculate contribution-based score"""
        total_repos = metrics.get('total_repositories', 0)
        total_contributions = metrics.get('public_contributions', 0)
        
        # Normalize: 50+ repos = 100, scale accordingly
        repo_score = min(100, (total_repos / 50) * 100)
        
        # Normalize: 1000+ contributions = 100
        contribution_score = min(100, (total_contributions / 1000) * 100)
        
        return (repo_score * 0.4 + contribution_score * 0.6)
    
    def _calculate_impact_score(self, metrics: Dict[str, Any]) -> float:
        """Calculate impact (stars, forks) score"""
        total_stars = metrics.get('total_stargazers_count', 0)
        total_forks = metrics.get('total_forks_count', 0)
        
        # Normalize: 500+ stars = 100
        stars_score = min(100, (total_stars / 500) * 100)
        
        # Normalize: 100+ forks = 100
        forks_score = min(100, (total_forks / 100) * 100)
        
        return (stars_score * 0.7 + forks_score * 0.3)
    
    def _calculate_consistency_score(self, metrics: Dict[str, Any]) -> float:
        """Calculate code consistency and activity score"""
        public_repos = metrics.get('public_repos', 1)
        avg_commits = metrics.get('average_commits_per_repo', 0)
        
        # Average commits per repo (higher is better)
        # 50+ commits per repo = 100
        consistency_score = min(100, (avg_commits / 50) * 100)
        
        # Active repositories ratio
        active_ratio = metrics.get('active_repositories_ratio', 0.5)
        activity_score = active_ratio * 100
        
        return (consistency_score * 0.6 + activity_score * 0.4)
    
    def _calculate_diversity_score(self, metrics: Dict[str, Any]) -> float:
        """Calculate language/tech stack diversity score"""
        languages = metrics.get('languages', {})
        num_languages = len(languages)
        
        # More languages = higher diversity (max benefit at 5+ languages)
        diversity_score = min(100, (num_languages / 5) * 100)
        
        # Language distribution balance (using entropy)
        if num_languages > 0:
            total_repos = sum(languages.values())
            if total_repos > 0:
                entropy = 0
                for count in languages.values():
                    p = count / total_repos
                    if p > 0:
                        entropy -= p * math.log2(p)
                
                # Max entropy for n languages is log2(n)
                max_entropy = math.log2(num_languages)
                balance_score = (entropy / max_entropy * 100) if max_entropy > 0 else 0
                
                return (diversity_score * 0.5 + balance_score * 0.5)
        
        return diversity_score
    
    def _calculate_collaboration_score(self, metrics: Dict[str, Any]) -> float:
        """Calculate collaboration and community engagement"""
        followers = metrics.get('followers', 0)
        following = metrics.get('following', 0)
        open_source_repos = metrics.get('open_source_repos', 0)
        
        # Follower score (1000+ = 100)
        follower_score = min(100, (followers / 1000) * 100)
        
        # Open source contribution ratio
        total_repos = metrics.get('total_repositories', 1)
        os_ratio = (open_source_repos / total_repos * 100) if total_repos > 0 else 0
        
        return (follower_score * 0.5 + os_ratio * 0.5)
    
    def analyze_tech_stack(self, repositories: List[Dict]) -> Dict[str, Any]:
        """
        Analyze technology stack from repositories
        
        Returns:
            Dictionary with tech stack analysis
        """
        languages = {}
        frameworks = {}
        tools = {}
        
        for repo in repositories:
            language = repo.get('language')
            if language:
                languages[language] = languages.get(language, 0) + 1
            
            # Parse topics/keywords for frameworks
            topics = repo.get('topics', [])
            for topic in topics:
                if topic:
                    frameworks[topic] = frameworks.get(topic, 0) + 1
        
        # Sort by frequency
        top_languages = sorted(
            languages.items(),
            key=lambda x: x[1],
            reverse=True
        )[:5]
        
        top_frameworks = sorted(
            frameworks.items(),
            key=lambda x: x[1],
            reverse=True
        )[:5]
        
        return {
            'primary_languages': [lang for lang, _ in top_languages],
            'languages_count': len(languages),
            'frameworks': [fw for fw, _ in top_frameworks],
            'full_breakdown': {
                'languages': dict(top_languages),
                'frameworks': dict(top_frameworks)
            }
        }
    
    def calculate_productivity_metrics(self, repositories: List[Dict]) -> Dict[str, Any]:
        """
        Calculate productivity metrics
        
        Returns:
            Productivity analysis
        """
        if not repositories:
            return {'score': 0, 'details': 'No repositories analyzed'}
        
        total_commits = 0
        active_repos = 0
        recent_updates = 0
        
        now = datetime.utcnow()
        thirty_days_ago = now - timedelta(days=30)
        
        for repo in repositories:
            if not repo.get('fork', False):
                active_repos += 1
                
                # Check if updated in last 30 days
                pushed_at = repo.get('pushed_at')
                if pushed_at:
                    try:
                        last_push = datetime.fromisoformat(
                            pushed_at.replace('Z', '+00:00')
                        )
                        if last_push > thirty_days_ago:
                            recent_updates += 1
                    except:
                        pass
        
        productivity_score = (active_repos / max(len(repositories), 1)) * 100
        recency_score = (recent_updates / max(active_repos, 1)) * 100 if active_repos > 0 else 0
        
        return {
            'productivity_score': min(100, productivity_score),
            'recency_score': min(100, recency_score),
            'active_repositories': active_repos,
            'recent_updates': recent_updates,
            'overall_score': (productivity_score * 0.6 + recency_score * 0.4)
        }
    
    def calculate_open_source_impact(self, profile: Dict, repositories: List[Dict]) -> float:
        """
        Calculate open source impact score
        
        Returns:
            Open source impact score (0-100)
        """
        public_repos = profile.get('public_repos', 0)
        total_stars = sum(repo.get('stargazers_count', 0) for repo in repositories)
        total_forks = sum(repo.get('forks_count', 0) for repo in repositories)
        followers = profile.get('followers', 0)
        
        # Weighted impact calculation
        stars_score = min(100, (total_stars / 500) * 100)
        forks_score = min(100, (total_forks / 100) * 100)
        follower_score = min(100, (followers / 1000) * 100)
        repo_score = min(100, (public_repos / 50) * 100)
        
        impact_score = (
            stars_score * 0.40 +
            forks_score * 0.25 +
            follower_score * 0.20 +
            repo_score * 0.15
        )
        
        return min(100, impact_score)
