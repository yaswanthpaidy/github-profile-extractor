"""
Response Models & Schemas for DevInsight AI
Pydantic models for API responses
"""

from pydantic import BaseModel, Field
from typing import Dict, List, Optional, Any
from enum import Enum


class DeveloperLevelEnum(str, Enum):
    """Developer experience levels"""
    BEGINNER = "beginner"
    INTERMEDIATE = "intermediate"
    ADVANCED = "advanced"
    EXPERT = "expert"


class RepositoryStats(BaseModel):
    """Repository statistics"""
    name: str
    description: Optional[str] = None
    language: Optional[str] = None
    stars: int = 0
    forks: int = 0
    watchers: int = 0
    open_issues: int = 0
    created_at: Optional[str] = None
    updated_at: Optional[str] = None
    url: str
    
    class Config:
        json_schema_extra = {
            "example": {
                "name": "awesome-project",
                "description": "An awesome project",
                "language": "Python",
                "stars": 150,
                "forks": 30,
                "url": "https://github.com/user/awesome-project"
            }
        }


class LanguageBreakdown(BaseModel):
    """Programming language usage breakdown"""
    language: str
    percentage: float
    repository_count: int
    
    class Config:
        json_schema_extra = {
            "example": {
                "language": "Python",
                "percentage": 45.5,
                "repository_count": 9
            }
        }


class TechStackAnalysis(BaseModel):
    """Technology stack analysis"""
    primary_languages: List[str]
    frameworks: List[str]
    tools: List[str] = []
    databases: List[str] = []
    cloud_platforms: List[str] = []
    
    class Config:
        json_schema_extra = {
            "example": {
                "primary_languages": ["Python", "JavaScript", "TypeScript"],
                "frameworks": ["FastAPI", "React", "Django"],
                "tools": ["Docker", "Kubernetes", "Git"],
                "databases": ["PostgreSQL", "MongoDB"],
                "cloud_platforms": ["AWS", "GCP"]
            }
        }


class DeveloperScore(BaseModel):
    """Comprehensive developer scoring"""
    overall_score: float = Field(..., ge=0, le=100, description="Overall score 0-100")
    contribution_score: float = Field(..., ge=0, le=100)
    impact_score: float = Field(..., ge=0, le=100)
    consistency_score: float = Field(..., ge=0, le=100)
    diversity_score: float = Field(..., ge=0, le=100)
    collaboration_score: float = Field(..., ge=0, le=100)
    level: DeveloperLevelEnum
    
    class Config:
        json_schema_extra = {
            "example": {
                "overall_score": 82.5,
                "contribution_score": 85,
                "impact_score": 75,
                "consistency_score": 88,
                "diversity_score": 80,
                "collaboration_score": 78,
                "level": "advanced"
            }
        }


class AIInsights(BaseModel):
    """AI-generated insights"""
    summary: str
    strengths: List[str]
    weaknesses: List[str]
    recommendations: List[str]
    career_recommendations: Dict[str, Any]
    generated_at: Optional[str] = None
    
    class Config:
        json_schema_extra = {
            "example": {
                "summary": "Experienced full-stack developer...",
                "strengths": ["Strong Python skills", "Good open-source contributor"],
                "weaknesses": ["Limited cloud experience", "Could improve documentation"],
                "recommendations": ["Contribute to enterprise projects", "Learn Kubernetes"],
                "career_recommendations": {
                    "roles": ["Senior Engineer", "Tech Lead"],
                    "industries": ["FinTech", "SaaS"]
                }
            }
        }


class ProductivityMetrics(BaseModel):
    """Productivity and activity metrics"""
    productivity_score: float = Field(..., ge=0, le=100)
    recency_score: float = Field(..., ge=0, le=100)
    consistency_score: float = Field(..., ge=0, le=100)
    active_repositories: int
    recent_updates: int
    average_commits_per_repo: float
    contribution_consistency: float
    
    class Config:
        json_schema_extra = {
            "example": {
                "productivity_score": 78.5,
                "recency_score": 85,
                "consistency_score": 82,
                "active_repositories": 15,
                "recent_updates": 12,
                "average_commits_per_repo": 42.5,
                "contribution_consistency": 0.82
            }
        }


class OpenSourceImpact(BaseModel):
    """Open source impact metrics"""
    open_source_score: float = Field(..., ge=0, le=100)
    total_stars: int
    total_forks: int
    followers: int
    contributed_to_count: int
    most_popular_repo: Optional[RepositoryStats] = None
    
    class Config:
        json_schema_extra = {
            "example": {
                "open_source_score": 72,
                "total_stars": 500,
                "total_forks": 100,
                "followers": 250,
                "contributed_to_count": 15
            }
        }


class DeveloperProfile(BaseModel):
    """Complete developer profile response"""
    username: str
    name: Optional[str] = None
    avatar_url: Optional[str] = None
    bio: Optional[str] = None
    location: Optional[str] = None
    blog: Optional[str] = None
    company: Optional[str] = None
    email: Optional[str] = None
    github_url: str
    twitter_username: Optional[str] = None
    followers: int
    following: int
    public_repos: int
    public_gists: int
    
    class Config:
        json_schema_extra = {
            "example": {
                "username": "johndoe",
                "name": "John Doe",
                "avatar_url": "https://avatars.githubusercontent.com/u/1?v=4",
                "bio": "Senior Developer",
                "location": "San Francisco",
                "github_url": "https://github.com/johndoe",
                "followers": 500,
                "following": 100,
                "public_repos": 30,
                "public_gists": 5
            }
        }


class AnalyticsResponse(BaseModel):
    """Complete analytics response"""
    profile: DeveloperProfile
    developer_score: DeveloperScore
    productivity_metrics: ProductivityMetrics
    tech_stack: TechStackAnalysis
    language_breakdown: List[LanguageBreakdown]
    open_source_impact: OpenSourceImpact
    ai_insights: AIInsights
    top_repositories: List[RepositoryStats]
    analysis_timestamp: str
    
    class Config:
        json_schema_extra = {
            "description": "Complete developer analytics response with all metrics and insights"
        }


class ErrorResponse(BaseModel):
    """Error response model"""
    error: str
    message: str
    status_code: int
    timestamp: str
    request_id: Optional[str] = None
    
    class Config:
        json_schema_extra = {
            "example": {
                "error": "Invalid GitHub Username",
                "message": "The provided GitHub username does not exist",
                "status_code": 404,
                "timestamp": "2024-01-01T12:00:00Z"
            }
        }


class HealthResponse(BaseModel):
    """Health check response"""
    status: str
    version: str
    environment: str
    services: Dict[str, str]
    timestamp: str
    
    class Config:
        json_schema_extra = {
            "example": {
                "status": "healthy",
                "version": "1.0.0",
                "environment": "production",
                "services": {
                    "api": "healthy",
                    "database": "healthy",
                    "cache": "healthy"
                },
                "timestamp": "2024-01-01T12:00:00Z"
            }
        }
