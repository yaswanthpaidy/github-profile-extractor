"""
Enhanced Response Models
Comprehensive Pydantic models for API responses
"""

from pydantic import BaseModel, Field
from typing import List, Dict, Optional, Any
from datetime import datetime


# ============ Profile Models ============

class GitHubProfileModel(BaseModel):
    """GitHub profile data"""
    username: str
    name: Optional[str] = None
    bio: Optional[str] = None
    location: Optional[str] = None
    email: Optional[str] = None
    blog: Optional[str] = None
    company: Optional[str] = None
    followers: int
    following: int
    public_repos: int
    avatar_url: str = Field(..., alias="avatar_url")
    profile_url: str = Field(..., alias="html_url")
    created_at: Optional[str] = None
    updated_at: Optional[str] = None

    class Config:
        allow_population_by_field_name = True
        json_schema_extra = {
            "example": {
                "username": "octocat",
                "name": "The Octocat",
                "bio": "GitHub's mascot",
                "followers": 1000,
                "following": 50,
                "public_repos": 25,
                "avatar_url": "https://...",
                "profile_url": "https://github.com/octocat"
            }
        }


class RepositoryModel(BaseModel):
    """Repository data"""
    name: str
    description: Optional[str] = None
    url: str
    language: Optional[str] = None
    stars: int = Field(..., alias="stargazers_count")
    forks: int = Field(..., alias="forks_count")
    watchers: int = Field(..., alias="watchers_count")
    size: int
    created_at: Optional[str] = None
    updated_at: Optional[str] = None
    is_fork: bool = Field(..., alias="fork")
    topics: List[str] = []
    
    class Config:
        populate_by_name = True
        json_schema_extra = {
            "example": {
                "name": "awesome-project",
                "description": "An awesome project",
                "language": "Python",
                "stargazers_count": 100,
                "forks_count": 20,
                "watchers_count": 50
            }
        }


# ============ Skill Models ============

class SkillModel(BaseModel):
    """Detected skill"""
    skill: str
    score: float = Field(..., le=100, ge=0)
    category: str


class SkillsAnalysisModel(BaseModel):
    """Skills extraction analysis"""
    detected_languages: List[str]
    tech_stack: Dict[str, List[str]]
    skill_categories: Dict[str, List[str]]
    top_skills: List[SkillModel]
    language_proficiency: Dict[str, float]
    skill_confidence: float = Field(..., le=100, ge=0)
    total_skills_detected: int


# ============ Analytics Models ============

class ProductivityScoreModel(BaseModel):
    """Productivity score metrics"""
    score: float = Field(..., le=100, ge=0)
    components: Dict[str, float]
    percentile: str


class CodingConsistencyModel(BaseModel):
    """Coding consistency metrics"""
    consistency_score: float = Field(..., le=100, ge=0)
    primary_language: str
    language_focus_percentage: float
    language_diversity: int
    recent_activity_percentage: float
    streak_status: str


class RepositoryQualityModel(BaseModel):
    """Repository quality metrics"""
    quality_score: float = Field(..., le=100, ge=0)
    average_stars_per_repo: float
    average_forks_per_repo: float
    repositories_with_description_percentage: float
    quality_distribution: Dict[str, int]


class CollaborationMetricsModel(BaseModel):
    """Collaboration metrics"""
    collaboration_score: float = Field(..., le=100, ge=0)
    followers: int
    following: int
    follower_following_ratio: float
    original_projects: int
    forked_projects: int
    collaboration_level: str


class CommunityEngagementModel(BaseModel):
    """Community engagement metrics"""
    stars_per_repo: float
    watchers_per_repo: float
    followers_per_repo: float
    engagement_score: float = Field(..., le=100, ge=0)


class OpenSourceImpactModel(BaseModel):
    """Open source impact metrics"""
    impact_score: float
    impact_level: str
    total_stars: int
    total_forks: int
    most_popular_repo: Optional[Dict[str, Any]] = None


class AdvancedAnalyticsModel(BaseModel):
    """Complete advanced analytics"""
    productivity_score: ProductivityScoreModel
    coding_consistency: CodingConsistencyModel
    repository_quality: RepositoryQualityModel
    collaboration_metrics: CollaborationMetricsModel
    community_engagement: CommunityEngagementModel
    open_source_impact: OpenSourceImpactModel
    contribution_patterns: Dict[str, Any]
    project_diversity: Dict[str, Any]
    learning_velocity: Dict[str, Any]
    code_quality_indicators: Dict[str, Any]


# ============ Career Models ============

class CareerRoleModel(BaseModel):
    """Career role recommendation"""
    role: str
    confidence: float = Field(..., le=100, ge=0)
    match_score: float = Field(..., le=1, ge=0)


class GrowthPathModel(BaseModel):
    """Career growth path"""
    role: str
    experience_required_years: int
    key_focus_areas: List[str]


class SkillGapModel(BaseModel):
    """Skill gap identification"""
    skill: str
    priority: str
    importance: str
    learning_resources: List[Dict[str, str]]


class MarketDemandModel(BaseModel):
    """Market demand information"""
    score: float = Field(..., le=100, ge=0)
    trend: str


class SalaryRangeModel(BaseModel):
    """Salary range estimates"""
    min: int
    max: int
    currency: str = "USD"
    year: int


class CareerRecommendationModel(BaseModel):
    """Complete career recommendations"""
    primary_role: CareerRoleModel
    other_suitable_roles: List[CareerRoleModel]
    growth_path: List[GrowthPathModel]
    specific_recommendations: List[str]
    skill_gaps: List[SkillGapModel]
    experience_level: str
    market_demand: MarketDemandModel
    salary_range: SalaryRangeModel
    next_steps: List[str]


# ============ AI Analysis Models ============

class StrengthsWeaknessesModel(BaseModel):
    """AI analysis of strengths and weaknesses"""
    strengths: List[str]
    weaknesses: List[str]
    overall_assessment: str


class AIAnalysisModel(BaseModel):
    """Complete AI analysis"""
    ai_summary: str
    strengths_weaknesses: StrengthsWeaknessesModel
    improvement_suggestions: List[str]
    predicted_roles: List[Dict[str, Any]]


# ============ Competitive Programming Models ============

class LeetCodeStatsModel(BaseModel):
    """LeetCode statistics"""
    username: str
    name: str
    ranking: str
    reputation: int
    problems_solved: Dict[str, int]
    platform: str = "LeetCode"


class CodeforcesStatsModel(BaseModel):
    """Codeforces statistics"""
    username: str
    rating: int
    max_rating: int
    rank: str
    contribution: int
    friend_of_count: int
    platform: str = "Codeforces"


class HackerRankStatsModel(BaseModel):
    """HackerRank statistics"""
    username: str
    name: str
    country: str
    badges: List[str]
    problems_solved: int
    platform: str = "HackerRank"


class CompetitiveProgrammingModel(BaseModel):
    """Aggregated competitive programming data"""
    leetcode: Optional[LeetCodeStatsModel] = None
    codeforces: Optional[CodeforcesStatsModel] = None
    hackerrank: Optional[HackerRankStatsModel] = None
    competitive_score: Optional[Dict[str, Any]] = None


# ============ Complete Profile Response ============

class DeveloperProfileResponseModel(BaseModel):
    """Complete developer profile analysis"""
    profile: GitHubProfileModel
    repositories: List[RepositoryModel]
    
    # Core Analytics
    developer_score: float = Field(..., le=100, ge=0)
    skills_analysis: SkillsAnalysisModel
    advanced_analytics: AdvancedAnalyticsModel
    
    # Career & AI
    career_recommendations: CareerRecommendationModel
    ai_analysis: Optional[AIAnalysisModel] = None
    
    # External Integrations
    competitive_programming: Optional[CompetitiveProgrammingModel] = None
    
    # Metadata
    analyzed_at: datetime = Field(default_factory=datetime.utcnow)
    analysis_version: str = "1.0.0"
    
    class Config:
        json_schema_extra = {
            "example": {
                "profile": {
                    "username": "developer",
                    "name": "John Developer",
                    "followers": 100
                }
            }
        }


# ============ Error Models ============

class ErrorResponseModel(BaseModel):
    """Error response"""
    error: str
    status_code: int
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    details: Optional[Dict[str, Any]] = None


# ============ Health Check Models ============

class HealthCheckModel(BaseModel):
    """Health check response"""
    status: str
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    version: str
    services: Dict[str, str]


# ============ Request Models ============

class AnalysisRequestModel(BaseModel):
    """Analysis request"""
    username: str = Field(..., min_length=1, max_length=100)
    include_competitive_programming: bool = False
    include_ai_analysis: bool = False
    
    class Config:
        json_schema_extra = {
            "example": {
                "username": "octocat",
                "include_competitive_programming": True,
                "include_ai_analysis": True
            }
        }
