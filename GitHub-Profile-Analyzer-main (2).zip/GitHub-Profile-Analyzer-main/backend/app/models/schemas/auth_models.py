"""
Authentication Models and Utilities
JWT-based authentication for DevInsight AI
"""

from pydantic import BaseModel, Field, EmailStr
from typing import Optional
from datetime import datetime, timedelta
from jose import JWTError, jwt
import logging
from functools import lru_cache

from app.config.settings import settings

logger = logging.getLogger(__name__)


# ============ Authentication Models ============

class TokenData(BaseModel):
    """Token data"""
    sub: str  # Subject (username or email)
    exp: datetime
    iat: datetime
    type: str = "access"  # access or refresh


class TokenResponseModel(BaseModel):
    """Token response"""
    access_token: str
    refresh_token: Optional[str] = None
    token_type: str = "bearer"
    expires_in: int  # seconds


class UserModel(BaseModel):
    """User model"""
    id: str
    username: str
    email: str
    name: Optional[str] = None
    avatar_url: Optional[str] = None
    created_at: datetime
    updated_at: datetime


class UserCreateModel(BaseModel):
    """User creation request"""
    username: str = Field(..., min_length=3, max_length=50)
    email: EmailStr
    password: str = Field(..., min_length=8, max_length=100)
    name: Optional[str] = Field(None, max_length=100)


class UserLoginModel(BaseModel):
    """User login request"""
    email: EmailStr
    password: str


class UserResponseModel(BaseModel):
    """User response (no password)"""
    id: str
    username: str
    email: str
    name: Optional[str] = None
    avatar_url: Optional[str] = None
    created_at: datetime
    updated_at: datetime


# ============ Password Hashing ============

from passlib.context import CryptContext

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def hash_password(password: str) -> str:
    """Hash password"""
    return pwd_context.hash(password)


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verify password"""
    return pwd_context.verify(plain_password, hashed_password)


# ============ JWT Token Management ============

class JWTTokenManager:
    """JWT token management"""
    
    def __init__(self, secret_key: str = settings.SECRET_KEY,
                 algorithm: str = settings.ALGORITHM,
                 access_token_expire_minutes: int = settings.ACCESS_TOKEN_EXPIRE_MINUTES,
                 refresh_token_expire_days: int = settings.REFRESH_TOKEN_EXPIRE_DAYS):
        """Initialize JWT manager"""
        self.secret_key = secret_key
        self.algorithm = algorithm
        self.access_token_expire = access_token_expire_minutes
        self.refresh_token_expire = refresh_token_expire_days
    
    def create_access_token(self, subject: str) -> str:
        """
        Create access token
        
        Args:
            subject: Token subject (username or user ID)
            
        Returns:
            Encoded JWT token
        """
        
        now = datetime.utcnow()
        expires = now + timedelta(minutes=self.access_token_expire)
        
        payload = {
            "sub": subject,
            "exp": expires,
            "iat": now,
            "type": "access"
        }
        
        return jwt.encode(payload, self.secret_key, algorithm=self.algorithm)
    
    def create_refresh_token(self, subject: str) -> str:
        """
        Create refresh token
        
        Args:
            subject: Token subject
            
        Returns:
            Encoded JWT token
        """
        
        now = datetime.utcnow()
        expires = now + timedelta(days=self.refresh_token_expire)
        
        payload = {
            "sub": subject,
            "exp": expires,
            "iat": now,
            "type": "refresh"
        }
        
        return jwt.encode(payload, self.secret_key, algorithm=self.algorithm)
    
    def create_tokens(self, subject: str) -> TokenResponseModel:
        """
        Create both access and refresh tokens
        
        Args:
            subject: Token subject
            
        Returns:
            TokenResponseModel with both tokens
        """
        
        access_token = self.create_access_token(subject)
        refresh_token = self.create_refresh_token(subject)
        
        return TokenResponseModel(
            access_token=access_token,
            refresh_token=refresh_token,
            token_type="bearer",
            expires_in=self.access_token_expire * 60  # Convert to seconds
        )
    
    def verify_token(self, token: str) -> Optional[TokenData]:
        """
        Verify and decode JWT token
        
        Args:
            token: JWT token
            
        Returns:
            TokenData if valid, None otherwise
        """
        
        try:
            payload = jwt.decode(token, self.secret_key, algorithms=[self.algorithm])
            
            subject = payload.get("sub")
            if not subject:
                return None
            
            exp = payload.get("exp")
            iat = payload.get("iat")
            token_type = payload.get("type", "access")
            
            return TokenData(
                sub=subject,
                exp=datetime.fromtimestamp(exp) if exp else None,
                iat=datetime.fromtimestamp(iat) if iat else None,
                type=token_type
            )
            
        except JWTError as e:
            logger.error(f"Token verification error: {str(e)}")
            return None
    
    def verify_access_token(self, token: str) -> Optional[str]:
        """
        Verify access token and return subject
        
        Args:
            token: JWT token
            
        Returns:
            Subject if valid, None otherwise
        """
        
        token_data = self.verify_token(token)
        
        if not token_data:
            return None
        
        if token_data.type != "access":
            logger.warning("Invalid token type")
            return None
        
        return token_data.sub
    
    def verify_refresh_token(self, token: str) -> Optional[str]:
        """
        Verify refresh token and return subject
        
        Args:
            token: JWT token
            
        Returns:
            Subject if valid, None otherwise
        """
        
        token_data = self.verify_token(token)
        
        if not token_data:
            return None
        
        if token_data.type != "refresh":
            logger.warning("Invalid token type")
            return None
        
        return token_data.sub


# ============ JWT Manager Instance ============

@lru_cache()
def get_jwt_manager() -> JWTTokenManager:
    """Get JWT manager instance (singleton)"""
    return JWTTokenManager()


# ============ Session Models ============

class SessionModel(BaseModel):
    """User session"""
    id: str
    user_id: str
    access_token: str
    refresh_token: Optional[str] = None
    created_at: datetime
    expires_at: datetime
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None
    is_active: bool = True


class SessionCreateModel(BaseModel):
    """Session creation"""
    user_id: str
    access_token: str
    refresh_token: Optional[str] = None
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None


# ============ API Key Models ============

class APIKeyModel(BaseModel):
    """API Key for programmatic access"""
    id: str
    user_id: str
    name: str
    key_prefix: str  # First 8 characters
    created_at: datetime
    last_used_at: Optional[datetime] = None
    expires_at: Optional[datetime] = None
    is_active: bool = True


class APIKeyCreateModel(BaseModel):
    """API Key creation request"""
    name: str = Field(..., min_length=1, max_length=100)
    expires_in_days: Optional[int] = Field(None, ge=1)


class APIKeyResponseModel(BaseModel):
    """API Key response (key only shown once)"""
    id: str
    name: str
    key: str  # Full key (only shown once)
    created_at: datetime
    expires_at: Optional[datetime] = None


# ============ Verification Models ============

class EmailVerificationModel(BaseModel):
    """Email verification"""
    id: str
    user_id: str
    token: str
    created_at: datetime
    expires_at: datetime
    is_verified: bool


class PasswordResetModel(BaseModel):
    """Password reset request"""
    email: EmailStr


class PasswordResetConfirmModel(BaseModel):
    """Password reset confirmation"""
    token: str
    new_password: str = Field(..., min_length=8, max_length=100)
