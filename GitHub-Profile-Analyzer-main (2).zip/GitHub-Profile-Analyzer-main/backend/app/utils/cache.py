import time
from typing import Any, Optional

cache_store: dict[str, Any] = {}
cache_expiry: dict[str, float] = {}


def get_cache(key: str) -> Optional[Any]:
    """Return cached value if available and not expired."""
    expiry = cache_expiry.get(key)
    if expiry and expiry < time.time():
        cache_store.pop(key, None)
        cache_expiry.pop(key, None)
        return None

    return cache_store.get(key)


def set_cache(key: str, value: Any, ttl: int = 3600) -> None:
    """Store value in cache with TTL."""
    cache_store[key] = value
    cache_expiry[key] = time.time() + ttl


def clear_cache(key: str) -> None:
    """Remove a value from cache."""
    cache_store.pop(key, None)
    cache_expiry.pop(key, None)
