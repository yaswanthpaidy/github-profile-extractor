"""
Skill Extraction Engine
Advanced skill detection and classification from repositories
"""

import logging
from typing import Dict, List, Set
from collections import Counter

logger = logging.getLogger(__name__)

# Technology stacks by category
TECH_STACKS = {
    "frontend": {
        "React", "Vue", "Angular", "Svelte", "Next.js", "Nuxt",
        "TypeScript", "JavaScript", "CSS", "HTML", "SASS", "Tailwind"
    },
    "backend": {
        "Python", "Java", "Go", "Rust", "C#", "PHP", "Ruby",
        "Node.js", "Express", "Django", "Flask", "Spring"
    },
    "mobile": {
        "Swift", "Kotlin", "React Native", "Flutter", "Dart", "Objective-C"
    },
    "devops": {
        "Docker", "Kubernetes", "AWS", "Azure", "GCP", "Jenkins",
        "Terraform", "Ansible", "GitLab CI"
    },
    "data": {
        "Python", "R", "SQL", "Spark", "Hadoop", "TensorFlow",
        "PyTorch", "Pandas", "NumPy", "Scikit-learn"
    },
    "database": {
        "PostgreSQL", "MySQL", "MongoDB", "Redis", "Elasticsearch",
        "DynamoDB", "Cassandra", "Firebase"
    }
}

# Skill keywords mapping
SKILL_KEYWORDS = {
    "API Development": ["api", "rest", "graphql", "endpoint"],
    "Database Design": ["database", "sql", "mongo", "postgres"],
    "Cloud Architecture": ["aws", "azure", "gcp", "cloud"],
    "DevOps": ["docker", "kubernetes", "ci/cd", "jenkins"],
    "Machine Learning": ["tensorflow", "pytorch", "sklearn", "ml"],
    "Web Development": ["frontend", "backend", "react", "express"],
    "Mobile Development": ["ios", "android", "react native", "flutter"],
    "System Design": ["architecture", "design pattern", "scalability"],
    "Testing": ["test", "jest", "pytest", "coverage"],
    "Security": ["security", "encryption", "auth", "oauth"]
}

LANGUAGE_PROFICIENCY_WEIGHTS = {
    "Python": {"weight": 0.95, "categories": ["backend", "data"]},
    "JavaScript": {"weight": 0.92, "categories": ["frontend", "backend"]},
    "TypeScript": {"weight": 0.90, "categories": ["frontend", "backend"]},
    "Java": {"weight": 0.88, "categories": ["backend"]},
    "Go": {"weight": 0.87, "categories": ["backend", "devops"]},
    "Rust": {"weight": 0.89, "categories": ["backend", "devops"]},
    "C++": {"weight": 0.86, "categories": ["backend"]},
    "C#": {"weight": 0.85, "categories": ["backend", "mobile"]},
    "PHP": {"weight": 0.78, "categories": ["backend"]},
    "Ruby": {"weight": 0.83, "categories": ["backend"]},
    "Swift": {"weight": 0.84, "categories": ["mobile"]},
    "Kotlin": {"weight": 0.82, "categories": ["mobile"]},
    "React": {"weight": 0.90, "categories": ["frontend"]},
    "Vue": {"weight": 0.87, "categories": ["frontend"]},
    "Angular": {"weight": 0.86, "categories": ["frontend"]},
}


def extract_skills_from_repositories(repositories: List[Dict]) -> Dict:
    """
    Extract and classify skills from repositories
    
    Args:
        repositories: List of repository data
        
    Returns:
        Dictionary with extracted skills and analysis
    """
    if not repositories:
        return {
            "detected_languages": [],
            "tech_stack": {},
            "skill_categories": {},
            "top_skills": [],
            "language_proficiency": {},
            "skill_confidence": 0
        }
    
    # Extract languages
    languages = extract_languages(repositories)
    
    # Identify technology stack
    tech_stack = identify_tech_stack(languages, repositories)
    
    # Extract repository metadata
    repo_metadata = extract_repository_metadata(repositories)
    
    # Classify skills by category
    skill_categories = classify_skills(languages, repo_metadata)
    
    # Calculate proficiency
    language_proficiency = calculate_language_proficiency(languages)
    
    # Get top skills
    top_skills = get_top_skills(languages, tech_stack, skill_categories)
    
    # Calculate confidence
    confidence = calculate_skill_extraction_confidence(repositories, languages)
    
    return {
        "detected_languages": sorted(languages),
        "tech_stack": tech_stack,
        "skill_categories": skill_categories,
        "top_skills": top_skills,
        "language_proficiency": language_proficiency,
        "skill_confidence": confidence,
        "total_skills_detected": len(languages) + len(tech_stack.get("tools", []))
    }


def extract_languages(repositories: List[Dict]) -> Set[str]:
    """Extract primary programming languages from repositories"""
    languages = set()
    
    for repo in repositories:
        if repo.get("language"):
            languages.add(repo["language"])
    
    # Add secondary languages from repository analysis
    for repo in repositories:
        if repo.get("description"):
            desc = repo["description"].lower()
            for lang in LANGUAGE_PROFICIENCY_WEIGHTS.keys():
                if lang.lower() in desc:
                    languages.add(lang)
    
    return languages


def identify_tech_stack(languages: Set[str], repositories: List[Dict]) -> Dict[str, List]:
    """Identify technology stack by category"""
    stack = {
        "frontend": [],
        "backend": [],
        "mobile": [],
        "devops": [],
        "data": [],
        "database": [],
        "tools": []
    }
    
    # Categorize detected languages
    for lang in languages:
        for category, techs in TECH_STACKS.items():
            if lang in techs:
                stack[category].append(lang)
    
    # Detect additional tools from repository metadata
    for repo in repositories:
        names = [repo.get("name", "").lower(), repo.get("description", "").lower()]
        repo_text = " ".join(names)
        
        for category, techs in TECH_STACKS.items():
            for tech in techs:
                if tech.lower() in repo_text and tech not in stack[category]:
                    stack[category].append(tech)
    
    # Remove empty categories
    return {k: v for k, v in stack.items() if v}


def extract_repository_metadata(repositories: List[Dict]) -> Dict[str, int]:
    """Extract metadata about repositories"""
    metadata = {
        "total_repositories": len(repositories),
        "total_stars": sum(r.get("stargazers_count", 0) for r in repositories),
        "total_forks": sum(r.get("forks_count", 0) for r in repositories),
        "repositories_with_description": sum(1 for r in repositories if r.get("description")),
        "average_stars": 0,
        "fork_ratio": 0
    }
    
    if repositories:
        metadata["average_stars"] = metadata["total_stars"] // len(repositories)
        metadata["fork_ratio"] = (
            metadata["total_forks"] / metadata["total_repositories"]
            if repositories else 0
        )
    
    return metadata


def classify_skills(languages: Set[str], metadata: Dict) -> Dict[str, List]:
    """Classify skills by category based on detected technologies"""
    classified = {}
    
    for skill, keywords in SKILL_KEYWORDS.items():
        detected_keywords = []
        for keyword in keywords:
            for lang in languages:
                if keyword.lower() in lang.lower():
                    detected_keywords.append(lang)
        
        if detected_keywords:
            classified[skill] = list(set(detected_keywords))
    
    return classified


def calculate_language_proficiency(languages: Set[str]) -> Dict[str, float]:
    """Calculate proficiency scores for detected languages"""
    proficiency = {}
    
    for lang in languages:
        if lang in LANGUAGE_PROFICIENCY_WEIGHTS:
            weight = LANGUAGE_PROFICIENCY_WEIGHTS[lang]["weight"]
        else:
            weight = 0.75  # Default weight for unknown languages
        
        proficiency[lang] = weight
    
    # Sort by proficiency
    return dict(sorted(proficiency.items(), key=lambda x: x[1], reverse=True))


def get_top_skills(languages: Set[str], tech_stack: Dict, 
                   skill_categories: Dict) -> List[Dict]:
    """Get top skills ranked by importance"""
    skills_with_scores = []
    
    # Score based on language proficiency
    for lang in languages:
        if lang in LANGUAGE_PROFICIENCY_WEIGHTS:
            score = LANGUAGE_PROFICIENCY_WEIGHTS[lang]["weight"] * 100
            skills_with_scores.append({
                "skill": lang,
                "score": score,
                "category": "programming_language"
            })
    
    # Score based on category
    for category, techs in tech_stack.items():
        if category != "tools":
            for tech in techs:
                score = 85 if category else 70
                skills_with_scores.append({
                    "skill": tech,
                    "score": score,
                    "category": category
                })
    
    # Sort and return top 10
    return sorted(
        skills_with_scores,
        key=lambda x: x["score"],
        reverse=True
    )[:10]


def calculate_skill_extraction_confidence(repositories: List[Dict], 
                                         languages: Set[str]) -> float:
    """Calculate confidence score for skill extraction"""
    if not repositories or not languages:
        return 0.0
    
    # Factors affecting confidence
    factors = {
        "language_variety": min(len(languages) / 5, 1.0),  # More languages = higher confidence
        "repo_metadata": sum(
            1 for repo in repositories 
            if repo.get("description") or repo.get("topics")
        ) / len(repositories),
        "repository_count": min(len(repositories) / 10, 1.0),
    }
    
    # Calculate weighted average
    confidence = (
        factors["language_variety"] * 0.4 +
        factors["repo_metadata"] * 0.3 +
        factors["repository_count"] * 0.3
    )
    
    return round(confidence * 100, 2)
