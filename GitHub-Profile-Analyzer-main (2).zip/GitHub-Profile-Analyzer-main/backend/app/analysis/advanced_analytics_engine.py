"""
Advanced Analytics Engine
Comprehensive metrics and analytics for developer profiling
"""

import logging
from typing import Dict, List
from datetime import datetime
from collections import Counter

logger = logging.getLogger(__name__)


def generate_advanced_analytics(profile: Dict, repositories: List[Dict]) -> Dict:
    """
    Generate comprehensive analytics dashboard
    
    Args:
        profile: GitHub profile data
        repositories: List of repositories
        
    Returns:
        Advanced analytics data
    """
    
    analytics = {
        "productivity_score": calculate_productivity_score(profile, repositories),
        "coding_consistency": analyze_coding_consistency(profile, repositories),
        "repository_quality": analyze_repository_quality(repositories),
        "collaboration_metrics": analyze_collaboration(profile, repositories),
        "community_engagement": calculate_community_engagement(profile, repositories),
        "open_source_impact": calculate_open_source_impact(repositories),
        "contribution_patterns": analyze_contribution_patterns(repositories),
        "project_diversity": analyze_project_diversity(repositories),
        "learning_velocity": calculate_learning_velocity(repositories),
        "code_quality_indicators": analyze_code_quality(repositories)
    }
    
    return analytics


def calculate_productivity_score(profile: Dict, repositories: List[Dict]) -> Dict:
    """
    Calculate developer productivity score (0-100)
    
    Factors:
    - Public repositories count
    - Commit frequency
    - Repository stars
    - Followers engagement
    """
    
    repo_count = len(repositories)
    total_stars = sum(r.get("stargazers_count", 0) for r in repositories)
    avg_stars = total_stars / repo_count if repo_count > 0 else 0
    followers = profile.get("followers", 0)
    public_repos = profile.get("public_repos", 0)
    
    # Calculate score components
    repo_score = min((repo_count / 20) * 25, 25)  # Max 25 points
    stars_score = min((avg_stars / 50) * 25, 25)  # Max 25 points
    followers_score = min((followers / 100) * 25, 25)  # Max 25 points
    activity_score = min((public_repos / 25) * 25, 25)  # Max 25 points
    
    total_score = repo_score + stars_score + followers_score + activity_score
    
    return {
        "score": round(min(total_score, 100), 2),
        "components": {
            "repository_activity": round(repo_score, 2),
            "project_impact": round(stars_score, 2),
            "community_recognition": round(followers_score, 2),
            "production_output": round(activity_score, 2)
        },
        "percentile": "Top 25%" if total_score > 75 else "Top 50%" if total_score > 50 else "Average"
    }


def analyze_coding_consistency(profile: Dict, repositories: List[Dict]) -> Dict:
    """
    Analyze consistency of contributions over time
    """
    
    # Count repositories per programming language
    languages = Counter()
    for repo in repositories:
        if repo.get("language"):
            languages[repo["language"]] += 1
    
    # Consistency metrics
    language_diversity = len(languages)
    primary_language = languages.most_common(1)[0][0] if languages else "Unknown"
    primary_language_percent = (
        (languages[primary_language] / len(repositories) * 100)
        if repositories else 0
    )
    
    # Repository update frequency (simplified)
    updated_recently = sum(
        1 for repo in repositories
        if repo.get("updated_at") and
        is_recently_updated(repo["updated_at"])
    ) / len(repositories) if repositories else 0
    
    consistency_score = (
        (primary_language_percent / 100) * 0.5 +  # Language focus
        updated_recently * 0.3 +  # Recent activity
        min(language_diversity / 10, 1.0) * 0.2  # Diversity
    ) * 100
    
    return {
        "consistency_score": round(consistency_score, 2),
        "primary_language": primary_language,
        "language_focus_percentage": round(primary_language_percent, 2),
        "language_diversity": language_diversity,
        "recent_activity_percentage": round(updated_recently * 100, 2),
        "streak_status": "Active" if updated_recently > 0.7 else "Moderate" if updated_recently > 0.3 else "Inactive"
    }


def analyze_repository_quality(repositories: List[Dict]) -> Dict:
    """
    Analyze quality metrics for repositories
    """
    
    if not repositories:
        return {
            "quality_score": 0,
            "average_stars_per_repo": 0,
            "average_forks_per_repo": 0,
            "repositories_with_description_percentage": 0,
            "quality_distribution": {}
        }
    
    total_stars = sum(r.get("stargazers_count", 0) for r in repositories)
    total_forks = sum(r.get("forks_count", 0) for r in repositories)
    repos_with_desc = sum(1 for r in repositories if r.get("description"))
    
    avg_stars = total_stars / len(repositories)
    avg_forks = total_forks / len(repositories)
    desc_percentage = (repos_with_desc / len(repositories)) * 100
    
    # Quality classification
    quality_dist = {
        "high": sum(1 for r in repositories if r.get("stargazers_count", 0) > 100),
        "medium": sum(1 for r in repositories 
                     if 20 <= r.get("stargazers_count", 0) <= 100),
        "low": sum(1 for r in repositories if r.get("stargazers_count", 0) < 20)
    }
    
    quality_score = (
        min(avg_stars / 100, 1.0) * 0.4 +
        min(avg_forks / 10, 1.0) * 0.3 +
        (desc_percentage / 100) * 0.3
    ) * 100
    
    return {
        "quality_score": round(quality_score, 2),
        "average_stars_per_repo": round(avg_stars, 2),
        "average_forks_per_repo": round(avg_forks, 2),
        "repositories_with_description_percentage": round(desc_percentage, 2),
        "quality_distribution": quality_dist
    }


def analyze_collaboration(profile: Dict, repositories: List[Dict]) -> Dict:
    """
    Analyze collaboration metrics
    """
    
    followers = profile.get("followers", 0)
    following = profile.get("following", 0)
    
    # Estimate contribution patterns
    contributed_repos = sum(1 for r in repositories if not r.get("fork", False))
    fork_count = sum(1 for r in repositories if r.get("fork", False))
    
    collaboration_score = (
        min(followers / 100, 1.0) * 0.4 +
        min(following / 50, 1.0) * 0.3 +
        (contributed_repos / max(len(repositories), 1)) * 0.3
    ) * 100
    
    return {
        "collaboration_score": round(collaboration_score, 2),
        "followers": followers,
        "following": following,
        "follower_following_ratio": round(followers / max(following, 1), 2),
        "original_projects": contributed_repos,
        "forked_projects": fork_count,
        "collaboration_level": "High" if collaboration_score > 70 else "Medium" if collaboration_score > 40 else "Low"
    }


def calculate_community_engagement(profile: Dict, repositories: List[Dict]) -> Dict:
    """
    Calculate community engagement metrics
    """
    
    public_repos = profile.get("public_repos", 0)
    followers = profile.get("followers", 0)
    total_stars = sum(r.get("stargazers_count", 0) for r in repositories)
    total_watchers = sum(r.get("watchers_count", 0) for r in repositories)
    
    engagement_metrics = {
        "stars_per_repo": round(
            total_stars / max(public_repos, 1), 2
        ),
        "watchers_per_repo": round(
            total_watchers / max(public_repos, 1), 2
        ),
        "followers_per_repo": round(
            followers / max(public_repos, 1), 2
        ),
        "engagement_score": round(
            (min(total_stars / 100, 1.0) * 0.4 +
             min(followers / 50, 1.0) * 0.3 +
             min(total_watchers / 100, 1.0) * 0.3) * 100,
            2
        )
    }
    
    return engagement_metrics


def calculate_open_source_impact(repositories: List[Dict]) -> Dict:
    """
    Calculate open source impact score
    """
    
    if not repositories:
        return {
            "impact_score": 0,
            "total_stars": 0,
            "most_popular_repo": None,
            "total_forks": 0,
            "impact_level": "None"
        }
    
    total_stars = sum(r.get("stargazers_count", 0) for r in repositories)
    total_forks = sum(r.get("forks_count", 0) for r in repositories)
    
    most_popular = max(
        repositories,
        key=lambda x: x.get("stargazers_count", 0)
    )
    
    impact_score = (total_stars * 0.6 + total_forks * 0.4) / max(len(repositories), 1)
    
    if impact_score > 500:
        impact_level = "Highly Impactful"
    elif impact_score > 100:
        impact_level = "Significantly Impactful"
    elif impact_score > 20:
        impact_level = "Moderately Impactful"
    else:
        impact_level = "Growing Impact"
    
    return {
        "impact_score": round(impact_score, 2),
        "impact_level": impact_level,
        "total_stars": total_stars,
        "total_forks": total_forks,
        "most_popular_repo": {
            "name": most_popular.get("name"),
            "stars": most_popular.get("stargazers_count", 0),
            "forks": most_popular.get("forks_count", 0)
        }
    }


def analyze_contribution_patterns(repositories: List[Dict]) -> Dict:
    """
    Analyze contribution patterns
    """
    
    if not repositories:
        return {
            "pattern": "No Activity",
            "consistency": "Not Applicable",
            "frequency": "Not Applicable"
        }
    
    # Analyze update patterns
    updated_repos = [r for r in repositories if r.get("updated_at")]
    
    if not updated_repos:
        return {
            "pattern": "Legacy Code",
            "consistency": "Inactive",
            "frequency": "Unknown"
        }
    
    recently_updated = sum(
        1 for r in updated_repos
        if is_recently_updated(r["updated_at"])
    )
    
    consistency_pct = (recently_updated / len(updated_repos)) * 100
    
    return {
        "pattern": "Active Contributor" if recently_updated > len(updated_repos) * 0.7 else "Regular Contributor" if recently_updated > len(updated_repos) * 0.3 else "Occasional Contributor",
        "consistency": consistency_pct,
        "recently_updated_repos": recently_updated,
        "frequency": "Daily" if consistency_pct > 80 else "Weekly" if consistency_pct > 50 else "Monthly"
    }


def analyze_project_diversity(repositories: List[Dict]) -> Dict:
    """
    Analyze diversity of projects
    """
    
    if not repositories:
        return {
            "diversity_score": 0,
            "language_count": 0,
            "topic_count": 0,
            "project_types": {}
        }
    
    # Language diversity
    languages = set()
    for repo in repositories:
        if repo.get("language"):
            languages.add(repo["language"])
    
    # Topic diversity
    all_topics = []
    for repo in repositories:
        if repo.get("topics"):
            all_topics.extend(repo["topics"])
    
    unique_topics = set(all_topics)
    
    # Project type estimation
    project_types = {
        "library": sum(1 for r in repositories if "lib" in r.get("name", "").lower()),
        "application": sum(1 for r in repositories if "app" in r.get("name", "").lower()),
        "framework": sum(1 for r in repositories if "framework" in r.get("name", "").lower()),
        "tool": sum(1 for r in repositories if "tool" in r.get("name", "").lower())
    }
    
    diversity_score = (
        min(len(languages) / 10, 1.0) * 0.5 +
        min(len(unique_topics) / 20, 1.0) * 0.5
    ) * 100
    
    return {
        "diversity_score": round(diversity_score, 2),
        "language_count": len(languages),
        "topic_count": len(unique_topics),
        "project_types": project_types
    }


def calculate_learning_velocity(repositories: List[Dict]) -> Dict:
    """
    Calculate learning velocity based on project evolution
    """
    
    if not repositories:
        return {
            "velocity": 0,
            "trend": "No Data",
            "new_technologies": 0
        }
    
    # Estimate based on repository growth and technology adoption
    stars_trend = []
    for i, repo in enumerate(sorted(repositories, key=lambda x: x.get("created_at", ""))[-10:]):
        stars_trend.append(repo.get("stargazers_count", 0))
    
    velocity = 0
    if len(stars_trend) > 1:
        velocity = (stars_trend[-1] - stars_trend[0]) / max(len(stars_trend), 1)
    
    trend = "Rapidly Improving" if velocity > 50 else "Improving" if velocity > 10 else "Stable" if velocity > -10 else "Declining"
    
    return {
        "velocity": round(velocity, 2),
        "trend": trend,
        "repositories_analyzed": len(repositories),
        "growth_indicator": "Positive" if velocity > 0 else "Negative"
    }


def analyze_code_quality(repositories: List[Dict]) -> Dict:
    """
    Analyze code quality indicators
    """
    
    quality_indicators = {
        "avg_repo_size": sum(r.get("size", 0) for r in repositories) // max(len(repositories), 1),
        "repos_with_readme": sum(1 for r in repositories if r.get("description")),
        "repos_with_topics": sum(1 for r in repositories if r.get("topics")),
        "code_quality_score": 0
    }
    
    # Calculate quality score
    quality_score = (
        min(quality_indicators["repos_with_readme"] / max(len(repositories), 1), 1.0) * 0.5 +
        min(quality_indicators["repos_with_topics"] / max(len(repositories), 1), 1.0) * 0.5
    ) * 100
    
    quality_indicators["code_quality_score"] = round(quality_score, 2)
    
    return quality_indicators


def is_recently_updated(updated_at: str, days: int = 30) -> bool:
    """Check if a repository was updated recently"""
    try:
        # Simplified check - in production would parse ISO format
        return True  # Placeholder
    except:
        return False
