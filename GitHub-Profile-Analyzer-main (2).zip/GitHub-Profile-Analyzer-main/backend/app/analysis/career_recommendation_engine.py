"""
Career Recommendation Engine
AI-powered career path prediction and recommendations
"""

import logging
from typing import Dict, List, Tuple
from enum import Enum

logger = logging.getLogger(__name__)


class CareerRole(Enum):
    """Career role classifications"""
    FULL_STACK = "Full-Stack Developer"
    BACKEND = "Backend Developer"
    FRONTEND = "Frontend Developer"
    MOBILE = "Mobile Developer"
    DEVOPS = "DevOps/Infrastructure Engineer"
    DATA_SCIENTIST = "Data Scientist"
    ML_ENGINEER = "Machine Learning Engineer"
    SECURITY = "Security Engineer"
    SYSTEMS = "Systems Engineer"
    ARCHITECT = "Solutions Architect"
    TECH_LEAD = "Technical Lead"
    CTO = "Chief Technology Officer"


# Role requirements mapping
ROLE_REQUIREMENTS = {
    "Full-Stack Developer": {
        "required_skills": ["frontend", "backend", "database"],
        "languages": ["JavaScript", "Python", "Java"],
        "experience_indicators": ["multiple_projects", "diverse_tech"]
    },
    "Backend Developer": {
        "required_skills": ["backend", "database", "api_design"],
        "languages": ["Python", "Java", "Go", "C#"],
        "experience_indicators": ["high_stars", "popular_libs"]
    },
    "Frontend Developer": {
        "required_skills": ["frontend", "ui_ux", "responsive"],
        "languages": ["JavaScript", "TypeScript", "HTML", "CSS"],
        "experience_indicators": ["react_projects", "design_repos"]
    },
    "Mobile Developer": {
        "required_skills": ["mobile", "ui", "performance"],
        "languages": ["Swift", "Kotlin", "React Native"],
        "experience_indicators": ["ios_projects", "android_projects"]
    },
    "DevOps/Infrastructure Engineer": {
        "required_skills": ["devops", "cloud", "containerization"],
        "languages": ["Docker", "Kubernetes", "AWS"],
        "experience_indicators": ["infra_repos", "automation"]
    },
    "Data Scientist": {
        "required_skills": ["data", "ml", "statistics"],
        "languages": ["Python", "R", "SQL"],
        "experience_indicators": ["data_repos", "ml_projects"]
    },
    "Machine Learning Engineer": {
        "required_skills": ["ml", "data", "deep_learning"],
        "languages": ["Python", "TensorFlow", "PyTorch"],
        "experience_indicators": ["ml_repos", "research"]
    },
    "Security Engineer": {
        "required_skills": ["security", "infrastructure", "cryptography"],
        "languages": ["Python", "Go", "Rust"],
        "experience_indicators": ["security_focus", "cve_fixes"]
    },
    "Solutions Architect": {
        "required_skills": ["architecture", "devops", "cloud"],
        "languages": ["multiple"],
        "experience_indicators": ["large_projects", "leadership"]
    }
}

# Growth path recommendations
GROWTH_PATHS = {
    "Full-Stack Developer": [
        "Solutions Architect",
        "Technical Lead",
        "CTO"
    ],
    "Backend Developer": [
        "DevOps/Infrastructure Engineer",
        "Solutions Architect",
        "Data Engineer"
    ],
    "Frontend Developer": [
        "Full-Stack Developer",
        "Solutions Architect"
    ],
    "Data Scientist": [
        "Machine Learning Engineer",
        "Data Engineer",
        "Solutions Architect"
    ]
}


def analyze_career_path(profile: Dict, repositories: List[Dict], 
                       skills: Dict, metrics: Dict) -> Dict:
    """
    Analyze and recommend career paths based on profile
    
    Args:
        profile: GitHub profile data
        repositories: List of repositories
        skills: Extracted skills data
        metrics: Developer metrics
        
    Returns:
        Career recommendations and analysis
    """
    
    # Identify suitable roles
    suitable_roles = identify_suitable_roles(
        repositories, skills, metrics
    )
    
    # Get top recommendation
    primary_role = suitable_roles[0] if suitable_roles else {
        "role": "Developer",
        "confidence": 50,
        "match_score": 0.5
    }
    
    # Get growth path
    growth_recommendations = get_growth_path(primary_role["role"])
    
    # Get specific recommendations
    specific_recommendations = get_specific_recommendations(
        primary_role["role"],
        repositories,
        skills
    )
    
    # Identify skill gaps
    skill_gaps = identify_skill_gaps(
        primary_role["role"],
        skills
    )
    
    return {
        "primary_role": primary_role,
        "other_suitable_roles": suitable_roles[1:4] if len(suitable_roles) > 1 else [],
        "growth_path": growth_recommendations,
        "specific_recommendations": specific_recommendations,
        "skill_gaps": skill_gaps,
        "experience_level": determine_experience_level(profile, repositories),
        "market_demand": get_market_demand_score(primary_role["role"]),
        "salary_range": get_salary_range(primary_role["role"]),
        "next_steps": generate_next_steps(primary_role["role"], skill_gaps)
    }


def identify_suitable_roles(repositories: List[Dict], 
                           skills: Dict, metrics: Dict) -> List[Dict]:
    """Identify suitable career roles based on skills"""
    role_scores = {}
    
    languages = set(skills.get("detected_languages", []))
    tech_stack = skills.get("tech_stack", {})
    
    for role_name, requirements in ROLE_REQUIREMENTS.items():
        score = calculate_role_match_score(
            languages,
            tech_stack,
            repositories,
            metrics,
            requirements
        )
        
        if score > 0.3:  # Only include roles with > 30% match
            role_scores[role_name] = score
    
    # Sort by score and return
    sorted_roles = sorted(role_scores.items(), key=lambda x: x[1], reverse=True)
    
    return [
        {
            "role": role,
            "confidence": round(score * 100, 2),
            "match_score": round(score, 3)
        }
        for role, score in sorted_roles[:5]
    ]


def calculate_role_match_score(languages: set, tech_stack: Dict,
                              repositories: List[Dict], metrics: Dict,
                              requirements: Dict) -> float:
    """Calculate how well a developer matches a role"""
    
    score = 0.0
    weight_sum = 0
    
    # Language match (40%)
    if requirements.get("languages"):
        lang_match = sum(
            1 for lang in requirements["languages"]
            if lang in languages
        ) / len(requirements["languages"])
        score += lang_match * 0.4
        weight_sum += 0.4
    
    # Skill category match (35%)
    skill_match = 0
    for category in requirements.get("required_skills", []):
        if category in tech_stack and tech_stack[category]:
            skill_match += 1
    
    if requirements.get("required_skills"):
        skill_match /= len(requirements["required_skills"])
        score += skill_match * 0.35
        weight_sum += 0.35
    
    # Experience indicators (25%)
    exp_score = 0
    if metrics.get("total_stars", 0) > 50:
        exp_score += 0.25
    if metrics.get("total_repositories", 0) > 10:
        exp_score += 0.25
    if metrics.get("average_stars", 0) > 5:
        exp_score += 0.25
    
    score += (exp_score / 0.75) * 0.25
    weight_sum += 0.25
    
    return score / weight_sum if weight_sum > 0 else 0


def get_growth_path(primary_role: str) -> List[Dict]:
    """Get recommended growth path for a role"""
    
    if primary_role not in GROWTH_PATHS:
        return []
    
    growth_roles = GROWTH_PATHS[primary_role]
    
    return [
        {
            "role": role,
            "experience_required_years": get_years_to_growth(primary_role, role),
            "key_focus_areas": get_focus_areas_for_role(role)
        }
        for role in growth_roles
    ]


def get_specific_recommendations(role: str, repositories: List[Dict],
                                skills: Dict) -> List[str]:
    """Get specific recommendations for career development"""
    
    recommendations = []
    
    languages = set(skills.get("detected_languages", []))
    
    if role == "Backend Developer":
        if "Go" not in languages:
            recommendations.append("Learn Go for high-performance backend systems")
        if "Rust" not in languages:
            recommendations.append("Master Rust for system-level programming")
        if len([r for r in repositories if r.get("stargazers_count", 0) > 100]) < 3:
            recommendations.append("Build and maintain popular open-source libraries")
    
    elif role == "Frontend Developer":
        if "TypeScript" not in languages:
            recommendations.append("Adopt TypeScript for type-safe frontend development")
        if "React" not in str(repositories):
            recommendations.append("Master React ecosystem and patterns")
        recommendations.append("Focus on responsive design and accessibility")
    
    elif role == "Full-Stack Developer":
        if len(languages) < 4:
            recommendations.append("Expand tech stack diversity")
        recommendations.append("Lead architectural decisions across stacks")
    
    elif role == "DevOps/Infrastructure Engineer":
        if "Kubernetes" not in str(repositories):
            recommendations.append("Master Kubernetes orchestration")
        recommendations.append("Deep dive into cloud infrastructure as code")
    
    elif role == "Data Scientist":
        recommendations.append("Build end-to-end ML projects")
        recommendations.append("Master statistical analysis and visualization")
    
    return recommendations[:4]  # Return top 4


def identify_skill_gaps(role: str, skills: Dict) -> List[Dict]:
    """Identify skill gaps for target role"""
    
    if role not in ROLE_REQUIREMENTS:
        return []
    
    requirements = ROLE_REQUIREMENTS[role]
    detected_languages = set(skills.get("detected_languages", []))
    
    gaps = []
    
    for lang in requirements.get("languages", []):
        if lang not in detected_languages:
            gaps.append({
                "skill": lang,
                "priority": "high",
                "importance": "essential_for_role",
                "learning_resources": get_learning_resources(lang)
            })
    
    return gaps[:5]  # Return top 5 gaps


def determine_experience_level(profile: Dict, repositories: List[Dict]) -> str:
    """Determine developer experience level"""
    
    years_active = 1  # Simplified - would calculate from profile creation
    repo_count = len(repositories)
    total_stars = sum(r.get("stargazers_count", 0) for r in repositories)
    followers = profile.get("followers", 0)
    
    score = (repo_count * 2) + (total_stars / 10) + (followers / 5)
    
    if score < 30:
        return "Entry Level (0-2 years)"
    elif score < 100:
        return "Junior (2-4 years)"
    elif score < 250:
        return "Mid-Level (4-7 years)"
    elif score < 500:
        return "Senior (7-10 years)"
    else:
        return "Principal/Architect (10+ years)"


def get_market_demand_score(role: str) -> Dict:
    """Get market demand information for a role"""
    
    demand_scores = {
        "Full-Stack Developer": {"score": 95, "trend": "stable"},
        "Backend Developer": {"score": 90, "trend": "increasing"},
        "Frontend Developer": {"score": 85, "trend": "stable"},
        "DevOps/Infrastructure Engineer": {"score": 92, "trend": "increasing"},
        "Data Scientist": {"score": 88, "trend": "increasing"},
        "Machine Learning Engineer": {"score": 89, "trend": "rapidly_increasing"},
        "Security Engineer": {"score": 90, "trend": "rapidly_increasing"},
        "Solutions Architect": {"score": 83, "trend": "stable"}
    }
    
    return demand_scores.get(role, {"score": 70, "trend": "stable"})


def get_salary_range(role: str) -> Dict:
    """Get salary range estimates for a role (USD, 2024)"""
    
    salary_data = {
        "Entry Level": {"min": 60000, "max": 85000},
        "Junior": {"min": 85000, "max": 110000},
        "Mid-Level": {"min": 110000, "max": 160000},
        "Senior": {"min": 160000, "max": 220000},
        "Principal": {"min": 220000, "max": 350000}
    }
    
    # Map roles to levels
    if role in ["Data Scientist", "Machine Learning Engineer"]:
        return {"min": 95000, "max": 200000, "currency": "USD", "year": 2024}
    elif role in ["Security Engineer", "Solutions Architect"]:
        return {"min": 120000, "max": 220000, "currency": "USD", "year": 2024}
    else:
        return {"min": 85000, "max": 180000, "currency": "USD", "year": 2024}


def generate_next_steps(role: str, skill_gaps: List[Dict]) -> List[str]:
    """Generate actionable next steps"""
    
    steps = [
        "Build a portfolio project showcasing this role",
        "Contribute to open-source projects in this domain",
        "Network with professionals in this field"
    ]
    
    if skill_gaps:
        steps.insert(1, f"Focus on learning: {skill_gaps[0]['skill']}")
    
    return steps


def get_years_to_growth(current_role: str, target_role: str) -> int:
    """Estimate years needed to transition to target role"""
    
    growth_timeline = {
        ("Full-Stack Developer", "Solutions Architect"): 5,
        ("Full-Stack Developer", "Technical Lead"): 4,
        ("Backend Developer", "Solutions Architect"): 6,
        ("Frontend Developer", "Full-Stack Developer"): 2,
        ("Data Scientist", "Machine Learning Engineer"): 3
    }
    
    return growth_timeline.get((current_role, target_role), 3)


def get_focus_areas_for_role(role: str) -> List[str]:
    """Get focus areas for skill development"""
    
    focus_areas = {
        "Solutions Architect": [
            "System Design",
            "Cloud Architecture",
            "Scalability",
            "Team Leadership"
        ],
        "Technical Lead": [
            "Code Quality",
            "Team Management",
            "Architecture",
            "Mentoring"
        ],
        "Machine Learning Engineer": [
            "Deep Learning",
            "Model Optimization",
            "Production ML",
            "Research"
        ]
    }
    
    return focus_areas.get(role, ["Technical Excellence", "Leadership"])


def get_learning_resources(skill: str) -> List[Dict]:
    """Get learning resources for a skill"""
    
    resources = {
        "Go": [
            {"type": "course", "name": "Go for DevOps"},
            {"type": "book", "name": "The Go Programming Language"}
        ],
        "Rust": [
            {"type": "course", "name": "The Rust Programming Language"},
            {"type": "project", "name": "Build a web server in Rust"}
        ],
        "Kubernetes": [
            {"type": "course", "name": "Kubernetes for Developers"},
            {"type": "hands-on", "name": "Deploy apps on K8s"}
        ]
    }
    
    return resources.get(skill, [
        {"type": "course", "name": f"Master {skill}"},
        {"type": "practice", "name": f"Build projects with {skill}"}
    ])
