"""
Enhanced GitHub Service
Async GitHub API integration with caching and error handling
"""

import logging
from typing import Optional, List, Dict, Any
import httpx

from app.config.settings import settings
from app.utils.cache import get_cache, set_cache

logger = logging.getLogger(__name__)


class GitHubService:
    """
    GitHub API Service with async support
    Handles profile fetching, repository analysis, and data caching
    """
    
    def __init__(self):
        """Initialize GitHub service"""
        self.base_url = settings.GITHUB_API_URL
        self.timeout = settings.GITHUB_API_TIMEOUT
        self.headers = self._build_headers()
    
    def _build_headers(self) -> Dict[str, str]:
        """Build request headers with GitHub token if available"""
        headers = {
            "Accept": "application/vnd.github.v3+json",
            "User-Agent": "DevInsight-AI"
        }
        if settings.GITHUB_TOKEN:
            headers["Authorization"] = f"token {settings.GITHUB_TOKEN}"
        return headers
    
    async def get_profile(self, username: str) -> Optional[Dict[str, Any]]:
        """
        Fetch GitHub user profile
        """
        cache_key = f"profile_{username}"
        cached = get_cache(cache_key)
        if cached:
            logger.info(f"Cache hit for profile: {username}")
            return cached

        url = f"{self.base_url}/users/{username}"
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.get(url, headers=self.headers)

            if response.status_code == 404:
                logger.warning(f"User not found: {username}")
                return None
            if response.status_code != 200:
                logger.error(f"GitHub API error: {response.status_code}")
                return None

            data = response.json()
            set_cache(cache_key, data, ttl=3600)
            return data

        except httpx.RequestError as e:
            logger.error(f"Error fetching profile: {str(e)}")
            return None

    async def get_repositories(self, username: str) -> Optional[List[Dict[str, Any]]]:
        """
        Fetch user repositories with pagination
        """
        cache_key = f"repos_{username}"
        cached = get_cache(cache_key)
        if cached:
            logger.info(f"Cache hit for repositories: {username}")
            return cached

        try:
            all_repos: List[Dict[str, Any]] = []
            page = 1
            per_page = 100

            async with httpx.AsyncClient(timeout=self.timeout) as client:
                while True:
                    url = f"{self.base_url}/users/{username}/repos"
                    params = {
                        "page": page,
                        "per_page": per_page,
                        "sort": "updated",
                        "direction": "desc"
                    }

                    response = await client.get(url, headers=self.headers, params=params)

                    if response.status_code == 404:
                        logger.warning(f"User not found: {username}")
                        return None
                    if response.status_code != 200:
                        logger.error(f"Failed to fetch repositories: {response.status_code}")
                        break

                    repos = response.json()
                    if not repos:
                        break

                    all_repos.extend(repos)
                    if "Link" not in response.headers:
                        break
                    page += 1

            logger.info(f"Fetched {len(all_repos)} repositories for {username}")
            set_cache(cache_key, all_repos, ttl=3600)
            return all_repos

        except httpx.RequestError as e:
            logger.error(f"Error fetching repositories: {str(e)}")
            return None

    async def get_user_events(self, username: str, limit: int = 30) -> List[Dict[str, Any]]:
        """Fetch user's recent public events"""
        try:
            url = f"{self.base_url}/users/{username}/events/public"
            params = {"per_page": min(limit, 30)}

            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.get(url, headers=self.headers, params=params)

            if response.status_code != 200:
                logger.warning(f"Could not fetch events for {username}")
                return []
            return response.json()

        except httpx.RequestError as e:
            logger.error(f"Error fetching events: {str(e)}")
            return []

    async def get_followers(self, username: str) -> Optional[List[Dict[str, Any]]]:
        """Fetch user's followers"""
        cache_key = f"followers_{username}"
        cached = get_cache(cache_key)
        if cached:
            return cached

        try:
            url = f"{self.base_url}/users/{username}/followers"
            params = {"per_page": 100}

            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.get(url, headers=self.headers, params=params)

            if response.status_code != 200:
                return None

            followers = response.json()
            set_cache(cache_key, followers, ttl=7200)
            return followers

        except httpx.RequestError as e:
            logger.error(f"Error fetching followers: {str(e)}")
            return None

    async def check_rate_limit(self) -> Dict[str, Any]:
        """Check GitHub API rate limit"""
        try:
            url = f"{self.base_url}/rate_limit"
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.get(url, headers=self.headers)

            if response.status_code == 200:
                return response.json()
            return {"remaining": 0, "limit": 0}

        except httpx.RequestError as e:
            logger.error(f"Error checking rate limit: {str(e)}")
            return {"remaining": 0, "limit": 0}
