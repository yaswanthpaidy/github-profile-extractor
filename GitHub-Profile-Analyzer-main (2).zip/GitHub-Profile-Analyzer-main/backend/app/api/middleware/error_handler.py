"""
Error Handler Middleware
Centralized error handling for API responses
"""

from fastapi.responses import JSONResponse
from datetime import datetime
import logging

logger = logging.getLogger(__name__)


def error_handler_middleware(exc: Exception):
    """
    Handle exceptions and return standardized error response
    """
    logger.error(f"Error: {str(exc)}", exc_info=True)
    
    return JSONResponse(
        status_code=500,
        content={
            "error": "Internal Server Error",
            "message": str(exc),
            "status_code": 500,
            "timestamp": datetime.utcnow().isoformat()
        }
    )


def handle_validation_error(exc):
    """Handle validation errors"""
    return JSONResponse(
        status_code=422,
        content={
            "error": "Validation Error",
            "message": "Invalid request parameters",
            "status_code": 422,
            "timestamp": datetime.utcnow().isoformat(),
            "details": exc.errors() if hasattr(exc, 'errors') else []
        }
    )
