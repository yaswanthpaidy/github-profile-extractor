"""
Analytics API Routes - v1
Core analytics and developer profile analysis endpoints
"""

from fastapi import APIRouter, Query, HTTPException
from typing import Optional
from datetime import datetime

from app.services.github_service import GitHubService
from app.core.analytics.scorer import AnalyticsEngine
from app.core.ai.summarizer import AIEngine
from app.models.schemas.response import (
    AnalyticsResponse,
    DeveloperProfile,
    DeveloperScore,
    ProductivityMetrics,
    OpenSourceImpact,
    AIInsights,
    TechStackAnalysis,
    LanguageBreakdown,
    RepositoryStats,
    ErrorResponse
)


router = APIRouter()

# Initialize services
github_service = GitHubService()
analytics_engine = AnalyticsEngine()
ai_engine = AIEngine()


@router.get(
    "/profile/{username}",
    response_model=AnalyticsResponse,
    summary="Analyze GitHub Developer Profile",
    description="Comprehensive analysis of a GitHub developer profile with scores, insights, and recommendations"
)
async def analyze_profile(
    username: str = Query(..., min_length=1, max_length=100),
    include_ai: bool = Query(True, description="Include AI-generated insights")
):
    """
    Analyze a GitHub developer profile and generate comprehensive analytics
    
    - **username**: GitHub username to analyze
    - **include_ai**: Include AI-powered insights (default: true)
    
    Returns complete developer analytics with scores, metrics, and insights
    """
    try:
        # Fetch profile data
        profile_data = await github_service.get_profile(username)
        if not profile_data:
            raise HTTPException(status_code=404, detail="GitHub user not found")
        
        # Fetch repositories
        repositories = await github_service.get_repositories(username)
        if repositories is None:
            repositories = []
        
        # Calculate metrics
        metrics = _calculate_metrics(profile_data, repositories)
        
        # Calculate developer score
        dev_score = analytics_engine.calculate_developer_score(metrics)
        
        # Calculate scores by category
        productivity = analytics_engine.calculate_productivity_metrics(repositories)
        os_impact = analytics_engine.calculate_open_source_impact(profile_data, repositories)
        tech_stack = analytics_engine.analyze_tech_stack(repositories)
        
        # Generate AI insights if requested
        ai_insights = None
        if include_ai:
            ai_insights = await ai_engine.generate_developer_summary(
                profile_data,
                repositories,
                {**metrics, 'developer_score': dev_score}
            )
        
        # Format response
        response = _format_analytics_response(
            profile_data,
            repositories,
            metrics,
            dev_score,
            productivity,
            os_impact,
            tech_stack,
            ai_insights
        )
        
        return response
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error analyzing profile: {str(e)}"
        )


@router.get(
    "/score/{username}",
    response_model=DeveloperScore,
    summary="Get Developer Score Only"
)
async def get_developer_score(username: str):
    """
    Get quick developer score (0-100) for a GitHub user
    
    - **username**: GitHub username
    """
    try:
        profile = await github_service.get_profile(username)
        if not profile:
            raise HTTPException(status_code=404, detail="User not found")
        
        repositories = await github_service.get_repositories(username) or []
        metrics = _calculate_metrics(profile, repositories)
        
        overall_score = analytics_engine.calculate_developer_score(metrics)
        
        # Determine level
        if overall_score >= 80:
            level = "expert"
        elif overall_score >= 60:
            level = "advanced"
        elif overall_score >= 40:
            level = "intermediate"
        else:
            level = "beginner"
        
        return DeveloperScore(
            overall_score=round(overall_score, 2),
            contribution_score=metrics.get('contribution_score', 0),
            impact_score=metrics.get('impact_score', 0),
            consistency_score=metrics.get('consistency_score', 0),
            diversity_score=metrics.get('diversity_score', 0),
            collaboration_score=metrics.get('collaboration_score', 0),
            level=level
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get(
    "/repositories/{username}",
    response_model=list[RepositoryStats],
    summary="Get Repository Statistics"
)
async def get_repositories(
    username: str,
    limit: int = Query(10, ge=1, le=100)
):
    """
    Get detailed statistics for a user's repositories
    
    - **username**: GitHub username
    - **limit**: Number of repositories to return (1-100)
    """
    try:
        repositories = await github_service.get_repositories(username)
        if repositories is None:
            raise HTTPException(status_code=404, detail="User not found")
        
        # Sort by stars and limit
        sorted_repos = sorted(
            repositories,
            key=lambda x: x.get('stargazers_count', 0),
            reverse=True
        )[:limit]
        
        return [
            RepositoryStats(
                name=repo.get('name'),
                description=repo.get('description'),
                language=repo.get('language'),
                stars=repo.get('stargazers_count', 0),
                forks=repo.get('forks_count', 0),
                watchers=repo.get('watchers_count', 0),
                open_issues=repo.get('open_issues_count', 0),
                created_at=repo.get('created_at'),
                updated_at=repo.get('updated_at'),
                url=repo.get('html_url')
            )
            for repo in sorted_repos
        ]
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get(
    "/tech-stack/{username}",
    response_model=TechStackAnalysis,
    summary="Get Technology Stack Analysis"
)
async def get_tech_stack(username: str):
    """
    Analyze the technology stack used by a developer
    
    - **username**: GitHub username
    """
    try:
        repositories = await github_service.get_repositories(username)
        if repositories is None:
            raise HTTPException(status_code=404, detail="User not found")
        
        tech_stack = analytics_engine.analyze_tech_stack(repositories)
        
        return TechStackAnalysis(
            primary_languages=tech_stack.get('primary_languages', []),
            frameworks=tech_stack.get('frameworks', []),
            tools=tech_stack.get('tools', []),
            databases=tech_stack.get('databases', []),
            cloud_platforms=tech_stack.get('cloud_platforms', [])
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ============ Helper Functions ============

def _calculate_metrics(profile, repositories):
    """Calculate all metrics for a profile"""
    metrics = {
        'total_repositories': profile.get('public_repos', 0),
        'total_stargazers_count': sum(
            repo.get('stargazers_count', 0) for repo in repositories
        ),
        'total_forks_count': sum(
            repo.get('forks_count', 0) for repo in repositories
        ),
        'public_contributions': profile.get('public_repos', 0) * 5,  # Estimate
        'followers': profile.get('followers', 0),
        'following': profile.get('following', 0),
        'public_repos': profile.get('public_repos', 0),
        'languages': _get_language_stats(repositories),
        'active_repositories_ratio': _get_active_ratio(repositories),
        'average_commits_per_repo': _estimate_commits(repositories),
        'open_source_repos': len([r for r in repositories if not r.get('fork', True)])
    }
    return metrics


def _get_language_stats(repositories):
    """Extract language statistics"""
    languages = {}
    for repo in repositories:
        lang = repo.get('language')
        if lang:
            languages[lang] = languages.get(lang, 0) + 1
    return languages


def _get_active_ratio(repositories):
    """Calculate ratio of active vs total repos"""
    if not repositories:
        return 0
    active = len([r for r in repositories if not r.get('fork', True)])
    return (active / len(repositories)) if repositories else 0


def _estimate_commits(repositories):
    """Estimate average commits per repository"""
    if not repositories:
        return 0
    total_commits = len(repositories) * 10  # Conservative estimate
    return total_commits / max(len(repositories), 1)


def _format_analytics_response(
    profile,
    repositories,
    metrics,
    dev_score,
    productivity,
    os_impact,
    tech_stack,
    ai_summary
):
    """Format complete analytics response"""
    
    # Determine level
    if dev_score >= 80:
        level = "expert"
    elif dev_score >= 60:
        level = "advanced"
    elif dev_score >= 40:
        level = "intermediate"
    else:
        level = "beginner"
    
    # Language breakdown
    languages = metrics.get('languages', {})
    total_repos = sum(languages.values()) if languages else 1
    language_breakdown = [
        LanguageBreakdown(
            language=lang,
            percentage=(count / total_repos) * 100,
            repository_count=count
        )
        for lang, count in languages.items()
    ]
    
    # Top repositories
    top_repos = sorted(
        repositories,
        key=lambda x: x.get('stargazers_count', 0),
        reverse=True
    )[:5]
    
    repository_stats = [
        RepositoryStats(
            name=repo.get('name'),
            description=repo.get('description'),
            language=repo.get('language'),
            stars=repo.get('stargazers_count', 0),
            forks=repo.get('forks_count', 0),
            watchers=repo.get('watchers_count', 0),
            open_issues=repo.get('open_issues_count', 0),
            created_at=repo.get('created_at'),
            updated_at=repo.get('updated_at'),
            url=repo.get('html_url')
        )
        for repo in top_repos
    ]
    
    return AnalyticsResponse(
        profile=DeveloperProfile(
            username=profile.get('login'),
            name=profile.get('name'),
            avatar_url=profile.get('avatar_url'),
            bio=profile.get('bio'),
            location=profile.get('location'),
            blog=profile.get('blog'),
            company=profile.get('company'),
            email=profile.get('email'),
            github_url=profile.get('html_url'),
            twitter_username=profile.get('twitter_username'),
            followers=profile.get('followers', 0),
            following=profile.get('following', 0),
            public_repos=profile.get('public_repos', 0),
            public_gists=profile.get('public_gists', 0)
        ),
        developer_score=DeveloperScore(
            overall_score=round(dev_score, 2),
            contribution_score=round(metrics.get('contribution_score', 0), 2),
            impact_score=round(os_impact['open_source_score'], 2),
            consistency_score=round(productivity['consistency_score'], 2),
            diversity_score=round(metrics.get('diversity_score', 0), 2),
            collaboration_score=round(metrics.get('collaboration_score', 0), 2),
            level=level
        ),
        productivity_metrics=ProductivityMetrics(
            productivity_score=round(productivity['productivity_score'], 2),
            recency_score=round(productivity['recency_score'], 2),
            consistency_score=round(productivity['consistency_score'], 2),
            active_repositories=productivity['active_repositories'],
            recent_updates=productivity['recent_updates'],
            average_commits_per_repo=round(metrics.get('average_commits_per_repo', 0), 2),
            contribution_consistency=round(metrics.get('active_repositories_ratio', 0), 2)
        ),
        tech_stack=TechStackAnalysis(
            primary_languages=tech_stack.get('primary_languages', []),
            frameworks=tech_stack.get('frameworks', []),
            tools=tech_stack.get('tools', []),
            databases=tech_stack.get('databases', []),
            cloud_platforms=tech_stack.get('cloud_platforms', [])
        ),
        language_breakdown=language_breakdown,
        open_source_impact=OpenSourceImpact(
            open_source_score=round(os_impact['open_source_score'], 2),
            total_stars=os_impact['total_stars'],
            total_forks=os_impact['total_forks'],
            followers=os_impact['followers'],
            contributed_to_count=len([r for r in repositories if not r.get('fork', False)]),
            most_popular_repo=repository_stats[0] if repository_stats else None
        ),
        ai_insights=AIInsights(
            summary=ai_summary or "Profile analysis completed",
            strengths=["Active contributor", "Diverse technology stack"],
            weaknesses=["Area for improvement"],
            recommendations=["Recommendation 1"],
            career_recommendations={"roles": ["Software Engineer"]},
            generated_at=datetime.utcnow().isoformat()
        ),
        top_repositories=repository_stats,
        analysis_timestamp=datetime.utcnow().isoformat()
    )
