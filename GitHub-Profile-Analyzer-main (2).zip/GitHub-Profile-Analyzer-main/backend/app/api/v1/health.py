"""
Health Check API Routes
Service health and status endpoints
"""

from fastapi import APIRouter
from datetime import datetime

from app.config.settings import settings
from app.models.schemas.response import HealthResponse

router = APIRouter()


@router.get("/", response_model=HealthResponse)
async def health_check():
    """
    Get API health status
    """
    return HealthResponse(
        status="healthy",
        version=settings.VERSION,
        environment=settings.ENVIRONMENT,
        services={
            "api": "healthy",
            "github": "operational",
            "cache": "operational"
        },
        timestamp=datetime.utcnow().isoformat()
    )


@router.get("/ready")
async def readiness_check():
    """
    Kubernetes readiness probe
    """
    return {"status": "ready"}


@router.get("/live")
async def liveness_check():
    """
    Kubernetes liveness probe
    """
    return {"status": "alive"}
