"""
Insights API Routes
AI-powered insights and recommendations endpoints
"""

from fastapi import APIRouter, Query, HTTPException
from datetime import datetime

from app.services.github_service import GitHubService
from app.core.analytics.scorer import AnalyticsEngine
from app.core.ai.summarizer import AIEngine
from app.models.schemas.response import AIInsights

router = APIRouter()

# Initialize services
github_service = GitHubService()
analytics_engine = AnalyticsEngine()
ai_engine = AIEngine()


@router.get("/summary/{username}", response_model=AIInsights)
async def get_ai_summary(username: str):
    """
    Get AI-generated developer summary
    
    - **username**: GitHub username
    """
    try:
        profile = await github_service.get_profile(username)
        if not profile:
            raise HTTPException(status_code=404, detail="User not found")
        
        repositories = await github_service.get_repositories(username) or []
        
        # Calculate basic metrics
        metrics = {
            'total_repositories': profile.get('public_repos', 0),
            'total_stargazers_count': sum(repo.get('stargazers_count', 0) for repo in repositories),
            'total_forks_count': sum(repo.get('forks_count', 0) for repo in repositories),
            'followers': profile.get('followers', 0),
            'languages': {repo.get('language'): 1 for repo in repositories if repo.get('language')}
        }
        
        dev_score = analytics_engine.calculate_developer_score(metrics)
        
        # Generate summary
        summary = await ai_engine.generate_developer_summary(
            profile,
            repositories,
            {**metrics, 'developer_score': dev_score}
        )
        
        return AIInsights(
            summary=summary,
            strengths=["Active contributor", "Diverse stack"],
            weaknesses=["Area for growth"],
            recommendations=["Suggestion 1"],
            career_recommendations={"roles": ["Engineer"]},
            generated_at=datetime.utcnow().isoformat()
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/recommendations/{username}")
async def get_recommendations(username: str):
    """
    Get AI career recommendations
    
    - **username**: GitHub username
    """
    try:
        profile = await github_service.get_profile(username)
        if not profile:
            raise HTTPException(status_code=404, detail="User not found")
        
        repositories = await github_service.get_repositories(username) or []
        metrics = {
            'developer_score': 75,
            'total_repositories': profile.get('public_repos', 0),
            'followers': profile.get('followers', 0)
        }
        
        recommendations = await ai_engine.generate_career_recommendations(profile, metrics)
        return recommendations
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/analysis/{username}")
async def get_strengths_analysis(username: str):
    """
    Get AI analysis of strengths and weaknesses
    
    - **username**: GitHub username
    """
    try:
        profile = await github_service.get_profile(username)
        if not profile:
            raise HTTPException(status_code=404, detail="User not found")
        
        repositories = await github_service.get_repositories(username) or []
        metrics = {'developer_score': 75}
        
        analysis = await ai_engine.generate_strengths_and_weaknesses(
            profile,
            repositories,
            metrics
        )
        return analysis
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/improvements/{username}")
async def get_improvement_suggestions(username: str):
    """
    Get specific improvement suggestions
    
    - **username**: GitHub username
    """
    try:
        profile = await github_service.get_profile(username)
        if not profile:
            raise HTTPException(status_code=404, detail="User not found")
        
        metrics = {'developer_score': 75}
        suggestions = await ai_engine.generate_improvement_suggestions(profile, metrics)
        
        return {
            "username": username,
            "suggestions": suggestions,
            "generated_at": datetime.utcnow().isoformat()
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
