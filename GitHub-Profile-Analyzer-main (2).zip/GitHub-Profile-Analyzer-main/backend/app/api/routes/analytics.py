"""
Analytics API Routes
Comprehensive endpoint for developer intelligence and analytics
"""

from fastapi import APIRouter, HTTPException, Query
from typing import Optional
import logging

from app.services.github_service import GitHubService
from app.analysis.skill_extraction_engine import extract_skills_from_repositories
from app.analysis.career_recommendation_engine import analyze_career_path
from app.analysis.advanced_analytics_engine import generate_advanced_analytics
from app.integrations.ai_apis.ai_service import get_ai_service
from app.integrations.external_apis.competitive_programming import CompetitiveProgrammingAggregator
from app.models.schemas.analytics_models import (
    DeveloperProfileResponseModel,
    ErrorResponseModel,
    AnalysisRequestModel
)
from app.utils.cache import get_cache, set_cache

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/analytics", tags=["Analytics"])

# Services
github_service = GitHubService()


@router.post("/analyze", response_model=DeveloperProfileResponseModel)
async def analyze_developer(
    request: AnalysisRequestModel,
    use_cache: bool = Query(True, description="Use cached results if available")
) -> DeveloperProfileResponseModel:
    """
    Comprehensive developer analysis endpoint
    
    Analyzes a GitHub profile and provides:
    - Skill extraction and classification
    - Advanced analytics metrics
    - Career recommendations
    - Optional: AI-powered insights
    - Optional: Competitive programming stats
    
    Args:
        request: Analysis request with username
        use_cache: Whether to use cached results
        
    Returns:
        Complete developer profile analysis
    """
    
    username = request.username.strip()
    
    # Check cache
    if use_cache:
        cached = get_cache(f"analysis_{username}")
        if cached:
            logger.info(f"Cache hit for analysis: {username}")
            return cached
    
    try:
        # Fetch GitHub data
        logger.info(f"Fetching data for: {username}")
        
        profile = await github_service.get_profile(username)
        if not profile:
            raise HTTPException(status_code=404, detail="GitHub user not found")
        
        repositories = await github_service.get_repositories(username)
        if not repositories:
            repositories = []
        
        # Calculate all metrics
        developer_score = _calculate_developer_score(profile, repositories)
        skills = extract_skills_from_repositories(repositories)
        analytics = generate_advanced_analytics(profile, repositories)
        career = analyze_career_path(profile, repositories, skills, analytics)
        
        # Optional: AI Analysis
        ai_analysis = None
        if request.include_ai_analysis:
            ai_analysis = await _get_ai_analysis(username, profile, repositories)
        
        # Optional: Competitive Programming
        competitive_programming = None
        if request.include_competitive_programming:
            competitive_programming = await _get_competitive_programming_stats(username)
        
        # Build response
        response = DeveloperProfileResponseModel(
            profile=profile,
            repositories=repositories,
            developer_score=developer_score,
            skills_analysis=skills,
            advanced_analytics=analytics,
            career_recommendations=career,
            ai_analysis=ai_analysis,
            competitive_programming=competitive_programming
        )
        
        # Cache result
        set_cache(f"analysis_{username}", response)
        
        logger.info(f"Analysis completed for: {username}")
        return response
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Analysis error: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail="Error analyzing developer profile"
        )


@router.get("/profile/{username}")
async def get_profile_quick(
    username: str,
    use_cache: bool = Query(True)
) -> dict:
    """
    Quick profile fetch without full analysis
    
    Args:
        username: GitHub username
        use_cache: Use cached results
        
    Returns:
        Basic profile information
    """
    
    try:
        profile = await github_service.get_profile(username)
        if not profile:
            raise HTTPException(status_code=404, detail="User not found")
        
        return {
            "username": profile.get("login"),
            "name": profile.get("name"),
            "bio": profile.get("bio"),
            "avatar_url": profile.get("avatar_url"),
            "followers": profile.get("followers"),
            "following": profile.get("following"),
            "public_repos": profile.get("public_repos"),
            "profile_url": profile.get("html_url")
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching profile: {str(e)}")
        raise HTTPException(status_code=500, detail="Error fetching profile")


@router.get("/skills/{username}")
async def get_skills_analysis(
    username: str,
    use_cache: bool = Query(True)
) -> dict:
    """
    Get skill extraction and analysis
    
    Args:
        username: GitHub username
        use_cache: Use cached results
        
    Returns:
        Extracted skills and tech stack
    """
    
    try:
        cache_key = f"skills_{username}"
        
        if use_cache:
            cached = get_cache(cache_key)
            if cached:
                return cached
        
        repositories = await github_service.get_repositories(username)
        if not repositories:
            repositories = []
        
        skills = extract_skills_from_repositories(repositories)
        
        set_cache(cache_key, skills)
        return skills
        
    except Exception as e:
        logger.error(f"Skills analysis error: {str(e)}")
        raise HTTPException(status_code=500, detail="Error analyzing skills")


@router.get("/analytics/{username}")
async def get_analytics(
    username: str,
    use_cache: bool = Query(True)
) -> dict:
    """
    Get advanced analytics metrics
    
    Args:
        username: GitHub username
        use_cache: Use cached results
        
    Returns:
        Comprehensive analytics data
    """
    
    try:
        cache_key = f"analytics_{username}"
        
        if use_cache:
            cached = get_cache(cache_key)
            if cached:
                return cached
        
        profile = await github_service.get_profile(username)
        if not profile:
            raise HTTPException(status_code=404, detail="User not found")
        
        repositories = await github_service.get_repositories(username)
        if not repositories:
            repositories = []
        
        analytics = generate_advanced_analytics(profile, repositories)
        
        set_cache(cache_key, analytics)
        return analytics
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Analytics error: {str(e)}")
        raise HTTPException(status_code=500, detail="Error generating analytics")


@router.get("/career/{username}")
async def get_career_recommendations(
    username: str,
    use_cache: bool = Query(True)
) -> dict:
    """
    Get career path recommendations
    
    Args:
        username: GitHub username
        use_cache: Use cached results
        
    Returns:
        Career recommendations and growth paths
    """
    
    try:
        cache_key = f"career_{username}"
        
        if use_cache:
            cached = get_cache(cache_key)
            if cached:
                return cached
        
        profile = await github_service.get_profile(username)
        if not profile:
            raise HTTPException(status_code=404, detail="User not found")
        
        repositories = await github_service.get_repositories(username)
        if not repositories:
            repositories = []
        
        skills = extract_skills_from_repositories(repositories)
        analytics = generate_advanced_analytics(profile, repositories)
        
        career = analyze_career_path(profile, repositories, skills, analytics)
        
        set_cache(cache_key, career)
        return career
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Career analysis error: {str(e)}")
        raise HTTPException(status_code=500, detail="Error analyzing career path")


@router.get("/competitive/{username}")
async def get_competitive_stats(
    username: str,
    platforms: Optional[str] = Query(None, description="Comma-separated platforms: leetcode,codeforces,hackerrank")
) -> dict:
    """
    Get competitive programming statistics
    
    Args:
        username: Username (may vary by platform)
        platforms: Platforms to check (default: all)
        
    Returns:
        Competitive programming statistics
    """
    
    try:
        stats = await _get_competitive_programming_stats(username)
        
        if not stats:
            raise HTTPException(status_code=404, detail="No competitive programming data found")
        
        return stats
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Competitive programming error: {str(e)}")
        raise HTTPException(status_code=500, detail="Error fetching competitive stats")


@router.get("/repositories/{username}")
async def get_repositories(
    username: str,
    sort_by: str = Query("stars", description="Sort by: stars, forks, updated"),
    use_cache: bool = Query(True)
) -> dict:
    """
    Get detailed repository analysis
    
    Args:
        username: GitHub username
        sort_by: Sort repositories by field
        use_cache: Use cached results
        
    Returns:
        Repository data with analysis
    """
    
    try:
        repositories = await github_service.get_repositories(username)
        if not repositories:
            repositories = []
        
        # Sort repositories
        if sort_by == "stars":
            repositories = sorted(
                repositories,
                key=lambda x: x.get("stargazers_count", 0),
                reverse=True
            )
        elif sort_by == "forks":
            repositories = sorted(
                repositories,
                key=lambda x: x.get("forks_count", 0),
                reverse=True
            )
        elif sort_by == "updated":
            repositories = sorted(
                repositories,
                key=lambda x: x.get("updated_at", ""),
                reverse=True
            )
        
        return {
            "total_repositories": len(repositories),
            "repositories": repositories[:50]  # Return top 50
        }
        
    except Exception as e:
        logger.error(f"Repositories error: {str(e)}")
        raise HTTPException(status_code=500, detail="Error fetching repositories")


# ============ Helper Functions ============

def _calculate_developer_score(profile: dict, repositories: list) -> float:
    """Calculate developer score (0-100)"""
    
    score = 0
    
    # Repositories (max 25 points)
    repo_count = len(repositories)
    score += min((repo_count / 20) * 25, 25)
    
    # Stars (max 25 points)
    total_stars = sum(r.get("stargazers_count", 0) for r in repositories)
    score += min((total_stars / 100) * 25, 25)
    
    # Followers (max 25 points)
    followers = profile.get("followers", 0)
    score += min((followers / 100) * 25, 25)
    
    # Profile completeness (max 25 points)
    completeness = 0
    if profile.get("name"):
        completeness += 5
    if profile.get("bio"):
        completeness += 5
    if profile.get("location"):
        completeness += 5
    if profile.get("company"):
        completeness += 5
    if profile.get("blog"):
        completeness += 5
    
    score += completeness
    
    return min(round(score, 2), 100.0)


async def _get_ai_analysis(username: str, profile: dict, repositories: list) -> dict:
    """Get AI-powered analysis"""
    
    try:
        ai_service = get_ai_service("openai")
        
        summary = await ai_service.generate_summary(profile, repositories)
        strengths_weaknesses = await ai_service.analyze_strengths_weaknesses(profile, repositories)
        roles = await ai_service.predict_roles(profile, repositories)
        suggestions = await ai_service.get_improvement_suggestions(profile, repositories)
        
        return {
            "ai_summary": summary,
            "strengths_weaknesses": strengths_weaknesses,
            "improvement_suggestions": suggestions,
            "predicted_roles": roles
        }
        
    except Exception as e:
        logger.error(f"AI analysis error: {str(e)}")
        return None


async def _get_competitive_programming_stats(username: str) -> dict:
    """Get competitive programming statistics"""
    
    try:
        aggregator = CompetitiveProgrammingAggregator()
        stats = await aggregator.get_all_stats(username)
        
        if stats:
            score = aggregator.calculate_competitive_score(stats)
            stats["competitive_score"] = score
        
        return stats
        
    except Exception as e:
        logger.error(f"Competitive programming error: {str(e)}")
        return None
