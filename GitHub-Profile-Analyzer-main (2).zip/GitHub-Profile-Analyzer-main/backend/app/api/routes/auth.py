"""
Authentication Routes
User authentication, registration, and session management
"""

from fastapi import APIRouter, HTTPException, Depends, Header, status
from typing import Optional
import logging
from datetime import datetime

from sqlalchemy.ext.asyncio import AsyncSession

from app.database.session import get_session
from app.database.crud_module import (
    get_user_by_email,
    get_user_by_username,
    get_user_by_id,
    create_user,
    update_user_password,
)
from app.models.schemas.auth_models import (
    UserCreateModel,
    UserLoginModel,
    UserResponseModel,
    TokenResponseModel,
    JWTTokenManager,
    get_jwt_manager,
    hash_password,
    verify_password,
)

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/auth", tags=["Authentication"])

jwt_manager = get_jwt_manager()


@router.post("/register", response_model=UserResponseModel)
async def register(
    user_data: UserCreateModel,
    session: AsyncSession = Depends(get_session),
) -> UserResponseModel:
    """Register a new user."""
    existing_user = await get_user_by_email(session, user_data.email)
    if existing_user:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="User already registered with this email",
        )

    existing_username = await get_user_by_username(session, user_data.username)
    if existing_username:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Username already taken",
        )

    try:
        user = await create_user(
            session,
            {
                "username": user_data.username,
                "email": user_data.email,
                "hashed_password": hash_password(user_data.password),
                "name": user_data.name,
                "avatar_url": None,
            },
        )

        logger.info(f"User registered: {user.email}")
        return UserResponseModel(
            id=user.id,
            username=user.username,
            email=user.email,
            name=user.name,
            avatar_url=user.avatar_url,
            created_at=user.created_at,
            updated_at=user.updated_at,
        )
    except Exception as e:
        logger.error(f"Registration error: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Error during registration",
        )


@router.post("/login", response_model=TokenResponseModel)
async def login(
    credentials: UserLoginModel,
    session: AsyncSession = Depends(get_session),
) -> TokenResponseModel:
    """Authenticate user and issue JWT tokens."""
    user = await get_user_by_email(session, credentials.email)
    if not user or not verify_password(credentials.password, user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid email or password",
            headers={"WWW-Authenticate": "Bearer"},
        )

    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="User account is inactive",
        )

    tokens = jwt_manager.create_tokens(str(user.id))
    logger.info(f"User logged in: {user.email}")
    return tokens


@router.post("/refresh", response_model=TokenResponseModel)
async def refresh_token(refresh_token: str) -> TokenResponseModel:
    """Refresh a valid refresh token."""
    user_id = jwt_manager.verify_refresh_token(refresh_token)
    if not user_id:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired refresh token",
        )

    tokens = jwt_manager.create_tokens(user_id)
    logger.info(f"Token refreshed for user: {user_id}")
    return tokens


@router.get("/me", response_model=UserResponseModel)
async def get_current_user(
    authorization: Optional[str] = Header(None),
    session: AsyncSession = Depends(get_session),
) -> UserResponseModel:
    """Return current authenticated user."""
    user = await _authenticate_user(authorization, session)
    return UserResponseModel(
        id=user.id,
        username=user.username,
        email=user.email,
        name=user.name,
        avatar_url=user.avatar_url,
        created_at=user.created_at,
        updated_at=user.updated_at,
    )


@router.post("/logout")
async def logout(
    authorization: Optional[str] = Header(None),
    session: AsyncSession = Depends(get_session),
) -> dict:
    """Invalidate session (placeholder)."""
    _ = await _authenticate_user(authorization, session)
    logger.info("User logged out")
    return {"message": "Successfully logged out"}


@router.post("/change-password")
async def change_password(
    current_password: str,
    new_password: str,
    authorization: Optional[str] = Header(None),
    session: AsyncSession = Depends(get_session),
) -> dict:
    """Change the password for current user."""
    user = await _authenticate_user(authorization, session)
    if not verify_password(current_password, user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid current password",
        )

    await update_user_password(session, user.id, hash_password(new_password))
    logger.info(f"Password changed for user: {user.id}")
    return {"message": "Password changed successfully"}


async def _authenticate_user(
    authorization: Optional[str],
    session: AsyncSession,
):
    """Verify JWT access token and return user."""
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Missing or invalid authorization header",
        )

    token = authorization.split(" ")[1]
    user_id = jwt_manager.verify_access_token(token)
    if not user_id:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired token",
        )

    user = await get_user_by_id(session, int(user_id))
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found",
        )

    return user
