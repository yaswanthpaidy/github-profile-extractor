"""
Reports API Routes
Temporary stub for report routing while full report implementation is pending.
"""

from fastapi import APIRouter

router = APIRouter(tags=["Reports"])


@router.get("/reports/health")
async def reports_health() -> dict:
    return {"status": "reports route active"}
