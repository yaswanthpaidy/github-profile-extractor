"""
AI Integration Service
OpenAI and Google Gemini API integration for developer intelligence
"""

import logging
from typing import Optional, Dict, Any
from abc import ABC, abstractmethod

logger = logging.getLogger(__name__)


class AIServiceBase(ABC):
    """Base class for AI services"""
    
    @abstractmethod
    async def generate_summary(self, profile: Dict, repositories: list) -> str:
        """Generate developer summary"""
        pass
    
    @abstractmethod
    async def analyze_strengths_weaknesses(self, profile: Dict, repositories: list) -> Dict:
        """Analyze strengths and weaknesses"""
        pass
    
    @abstractmethod
    async def predict_roles(self, profile: Dict, repositories: list) -> list:
        """Predict suitable roles"""
        pass
    
    @abstractmethod
    async def get_improvement_suggestions(self, profile: Dict, repositories: list) -> list:
        """Get profile improvement suggestions"""
        pass


class OpenAIService(AIServiceBase):
    """OpenAI API Integration"""
    
    def __init__(self, api_key: Optional[str] = None):
        """Initialize OpenAI service"""
        self.api_key = api_key
        self.model = "gpt-4-turbo"
        
        # This would be initialized with actual OpenAI client
        # from openai import AsyncOpenAI
        # self.client = AsyncOpenAI(api_key=api_key)
    
    async def generate_summary(self, profile: Dict, repositories: list) -> str:
        """
        Generate AI-powered developer summary
        """
        
        if not self.api_key:
            logger.warning("OpenAI API key not configured")
            return self._generate_default_summary(profile, repositories)
        
        try:
            prompt = self._build_summary_prompt(profile, repositories)
            
            # This would use actual OpenAI API
            # response = await self.client.chat.completions.create(
            #     model=self.model,
            #     messages=[
            #         {"role": "system", "content": "You are an expert technical recruiter analyzing GitHub profiles."},
            #         {"role": "user", "content": prompt}
            #     ],
            #     temperature=0.7,
            #     max_tokens=500
            # )
            # return response.choices[0].message.content
            
            return self._generate_default_summary(profile, repositories)
            
        except Exception as e:
            logger.error(f"OpenAI API error: {str(e)}")
            return self._generate_default_summary(profile, repositories)
    
    async def analyze_strengths_weaknesses(self, profile: Dict, repositories: list) -> Dict:
        """
        Analyze developer's strengths and weaknesses
        """
        
        if not self.api_key:
            return self._generate_default_strengths_weaknesses(repositories)
        
        try:
            prompt = f"""Analyze this developer's GitHub profile and identify:
            
            Profile:
            - Username: {profile.get('login', 'Unknown')}
            - Public Repos: {len(repositories)}
            - Followers: {profile.get('followers', 0)}
            - Bio: {profile.get('bio', 'No bio')}
            
            Repositories Languages: {self._extract_languages(repositories)}
            
            Provide:
            1. Top 5 technical strengths
            2. Top 5 areas for improvement
            3. Overall assessment
            
            Format as JSON."""
            
            # Would use actual OpenAI API here
            return self._generate_default_strengths_weaknesses(repositories)
            
        except Exception as e:
            logger.error(f"Analysis error: {str(e)}")
            return self._generate_default_strengths_weaknesses(repositories)
    
    async def predict_roles(self, profile: Dict, repositories: list) -> list:
        """
        Predict suitable roles for the developer
        """
        
        if not self.api_key:
            return self._generate_default_roles(repositories)
        
        try:
            prompt = f"""Based on this developer's GitHub activity and skills,
            predict the top 5 most suitable roles they could excel in.
            
            Skills detected: {self._extract_skills(repositories)}
            Project count: {len(repositories)}
            
            Return as JSON array with role name and confidence percentage."""
            
            return self._generate_default_roles(repositories)
            
        except Exception as e:
            logger.error(f"Role prediction error: {str(e)}")
            return self._generate_default_roles(repositories)
    
    async def get_improvement_suggestions(self, profile: Dict, repositories: list) -> list:
        """
        Get specific suggestions for profile improvement
        """
        
        if not self.api_key:
            return self._generate_default_suggestions(repositories)
        
        try:
            prompt = f"""Provide 5 specific, actionable suggestions to improve this developer's GitHub profile
            and career prospects:
            
            Current Profile:
            - Repositories: {len(repositories)}
            - Stars: {sum(r.get('stargazers_count', 0) for r in repositories)}
            - Languages: {self._extract_languages(repositories)}
            
            Focus on: visibility, impact, quality, and marketability."""
            
            return self._generate_default_suggestions(repositories)
            
        except Exception as e:
            logger.error(f"Suggestions error: {str(e)}")
            return self._generate_default_suggestions(repositories)
    
    def _build_summary_prompt(self, profile: Dict, repositories: list) -> str:
        """Build summary generation prompt"""
        
        return f"""Provide a professional 2-3 sentence summary of this developer based on their GitHub profile:

        Username: {profile.get('login', 'Developer')}
        Bio: {profile.get('bio', 'No bio')}
        Public Repositories: {len(repositories)}
        Followers: {profile.get('followers', 0)}
        Top Languages: {', '.join(self._extract_languages(repositories)[:5])}
        
        Total Stars: {sum(r.get('stargazers_count', 0) for r in repositories)}
        Total Forks: {sum(r.get('forks_count', 0) for r in repositories)}
        
        Write a compelling summary that would appeal to recruiters and highlights this developer's expertise."""
    
    def _extract_languages(self, repositories: list) -> list:
        """Extract primary programming languages"""
        
        from collections import Counter
        languages = [r.get('language') for r in repositories if r.get('language')]
        counter = Counter(languages)
        return [lang for lang, _ in counter.most_common(5)]
    
    def _extract_skills(self, repositories: list) -> list:
        """Extract detected skills"""
        
        languages = self._extract_languages(repositories)
        
        # Determine skills based on languages
        skills = []
        
        if any(lang in languages for lang in ['Python', 'Java', 'C++', 'Go']):
            skills.append('Backend Development')
        
        if any(lang in languages for lang in ['JavaScript', 'TypeScript', 'React', 'Vue']):
            skills.append('Frontend Development')
        
        if any(lang in languages for lang in ['Swift', 'Kotlin']):
            skills.append('Mobile Development')
        
        if any(keyword in str(repositories).lower() for keyword in ['docker', 'kubernetes', 'aws']):
            skills.append('DevOps/Infrastructure')
        
        return skills
    
    def _generate_default_summary(self, profile: Dict, repositories: list) -> str:
        """Generate default summary when AI is unavailable"""
        
        languages = self._extract_languages(repositories)
        stars = sum(r.get('stargazers_count', 0) for r in repositories)
        
        summary = f"{profile.get('name', profile.get('login'))} is an experienced developer "
        
        if languages:
            summary += f"specializing in {', '.join(languages)}. "
        
        if stars > 100:
            summary += f"Their work has garnered {stars} stars, demonstrating significant community impact. "
        elif stars > 10:
            summary += "Their projects have received community recognition. "
        
        summary += f"With {len(repositories)} public repositories, they show a commitment to open-source development."
        
        return summary
    
    def _generate_default_strengths_weaknesses(self, repositories: list) -> Dict:
        """Generate default strengths and weaknesses"""
        
        languages = self._extract_languages(repositories)
        
        strengths = [
            f"Proficiency in {languages[0]}" if languages else "Multi-language experience",
            "Open-source contribution",
            "Project diversity"
        ]
        
        weaknesses = [
            "Potential gaps in emerging technologies",
            "Documentation could be improved",
            "Limited collaboration indicators"
        ]
        
        return {
            "strengths": strengths,
            "weaknesses": weaknesses,
            "overall_assessment": "Solid developer with good fundamentals"
        }
    
    def _generate_default_roles(self, repositories: list) -> list:
        """Generate default role predictions"""
        
        languages = self._extract_languages(repositories)
        
        roles = []
        
        if any(lang in languages for lang in ['Python', 'Java', 'Go']):
            roles.append({"role": "Backend Developer", "confidence": 85})
        
        if any(lang in languages for lang in ['JavaScript', 'TypeScript']):
            roles.append({"role": "Full-Stack Developer", "confidence": 80})
        
        if any(lang in languages for lang in ['React', 'Vue', 'Angular']):
            roles.append({"role": "Frontend Developer", "confidence": 78})
        
        if not roles:
            roles.append({"role": "Software Developer", "confidence": 70})
        
        return roles[:5]
    
    def _generate_default_suggestions(self, repositories: list) -> list:
        """Generate default improvement suggestions"""
        
        suggestions = [
            "Add comprehensive README files to all repositories",
            "Create a portfolio project showcasing your best work",
            "Contribute to popular open-source projects",
            "Document your most impactful project thoroughly",
            "Share technical blogs about your projects"
        ]
        
        if len(repositories) < 5:
            suggestions.insert(0, "Build and publish more projects")
        
        return suggestions[:5]


class GeminiService(AIServiceBase):
    """Google Gemini API Integration"""
    
    def __init__(self, api_key: Optional[str] = None):
        """Initialize Gemini service"""
        self.api_key = api_key
        
        # This would be initialized with actual Gemini client
        # import google.generativeai as genai
        # self.client = genai
    
    async def generate_summary(self, profile: Dict, repositories: list) -> str:
        """Generate AI-powered developer summary using Gemini"""
        
        if not self.api_key:
            # Fallback to OpenAI service
            openai_service = OpenAIService()
            return await openai_service.generate_summary(profile, repositories)
        
        try:
            # Would implement Gemini API call here
            openai_service = OpenAIService()
            return await openai_service.generate_summary(profile, repositories)
            
        except Exception as e:
            logger.error(f"Gemini API error: {str(e)}")
            openai_service = OpenAIService()
            return await openai_service.generate_summary(profile, repositories)
    
    async def analyze_strengths_weaknesses(self, profile: Dict, repositories: list) -> Dict:
        """Analyze using Gemini"""
        
        openai_service = OpenAIService()
        return await openai_service.analyze_strengths_weaknesses(profile, repositories)
    
    async def predict_roles(self, profile: Dict, repositories: list) -> list:
        """Predict roles using Gemini"""
        
        openai_service = OpenAIService()
        return await openai_service.predict_roles(profile, repositories)
    
    async def get_improvement_suggestions(self, profile: Dict, repositories: list) -> list:
        """Get suggestions using Gemini"""
        
        openai_service = OpenAIService()
        return await openai_service.get_improvement_suggestions(profile, repositories)


def get_ai_service(provider: str = "openai", api_key: Optional[str] = None) -> AIServiceBase:
    """Factory function to get AI service"""
    
    if provider.lower() == "gemini":
        return GeminiService(api_key)
    else:
        return OpenAIService(api_key)
