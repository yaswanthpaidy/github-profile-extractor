"""
External APIs Integration
LeetCode, Codeforces, and HackerRank API integration
"""

import logging
import aiohttp
import httpx
from typing import Optional, Dict, Any
from abc import ABC, abstractmethod

logger = logging.getLogger(__name__)


class ExternalAPISBase(ABC):
    """Base class for external API integrations"""
    
    @abstractmethod
    async def get_user_stats(self, username: str) -> Optional[Dict]:
        """Get user statistics"""
        pass
    
    @abstractmethod
    async def get_user_problems(self, username: str) -> Optional[Dict]:
        """Get user problems solved"""
        pass


class LeetCodeService(ExternalAPISBase):
    """LeetCode API Integration"""
    
    def __init__(self):
        """Initialize LeetCode service"""
        self.api_url = "https://leetcode.com/graphql"
        self.timeout = 10
    
    async def get_user_stats(self, username: str) -> Optional[Dict]:
        """
        Fetch user statistics from LeetCode
        
        Args:
            username: LeetCode username
            
        Returns:
            User statistics or None
        """
        
        try:
            query = f"""
            {{
                user(username: "{username}") {{
                    username
                    realName
                    profile {{
                        reputation
                        ranking
                    }}
                    submitStats {{
                        acSubmissionNum {{
                            difficulty
                            count
                            submissions
                        }}
                    }}
                }}
            }}
            """
            
            async with httpx.AsyncClient() as client:
                response = await client.post(
                    self.api_url,
                    json={"query": query},
                    timeout=self.timeout
                )
                
                if response.status_code == 200:
                    data = response.json()
                    
                    if "data" in data and data["data"].get("user"):
                        return self._parse_leetcode_response(data["data"]["user"])
            
            return None
            
        except Exception as e:
            logger.error(f"LeetCode API error: {str(e)}")
            return None
    
    async def get_user_problems(self, username: str) -> Optional[Dict]:
        """Get solved problems statistics"""
        
        try:
            query = f"""
            {{
                userProfileUserQuestionProgress(userSlug: "{username}") {{
                    numAcceptedQuestions
                    numFailedQuestions
                    numUntouchedQuestions
                    totalQuestions
                }}
            }}
            """
            
            async with httpx.AsyncClient() as client:
                response = await client.post(
                    self.api_url,
                    json={"query": query},
                    timeout=self.timeout
                )
                
                if response.status_code == 200:
                    data = response.json()
                    
                    if "data" in data:
                        return data["data"].get("userProfileUserQuestionProgress")
            
            return None
            
        except Exception as e:
            logger.error(f"LeetCode problems error: {str(e)}")
            return None
    
    def _parse_leetcode_response(self, user_data: Dict) -> Dict:
        """Parse LeetCode API response"""
        
        return {
            "username": user_data.get("username", "Unknown"),
            "name": user_data.get("realName", "Unknown"),
            "ranking": user_data.get("profile", {}).get("ranking", "Unranked"),
            "reputation": user_data.get("profile", {}).get("reputation", 0),
            "problems_solved": self._extract_problems_solved(
                user_data.get("submitStats", {}).get("acSubmissionNum", [])
            ),
            "platform": "LeetCode"
        }
    
    def _extract_problems_solved(self, submissions: list) -> Dict:
        """Extract problems solved by difficulty"""
        
        stats = {"easy": 0, "medium": 0, "hard": 0, "total": 0}
        
        for submission in submissions:
            difficulty = submission.get("difficulty", "").lower()
            count = submission.get("count", 0)
            
            if difficulty in stats:
                stats[difficulty] = count
        
        stats["total"] = sum([stats["easy"], stats["medium"], stats["hard"]])
        
        return stats


class CodeforcesService(ExternalAPISBase):
    """Codeforces API Integration"""
    
    def __init__(self):
        """Initialize Codeforces service"""
        self.api_url = "https://codeforces.com/api"
        self.timeout = 10
    
    async def get_user_stats(self, username: str) -> Optional[Dict]:
        """
        Fetch user statistics from Codeforces
        
        Args:
            username: Codeforces username
            
        Returns:
            User statistics or None
        """
        
        try:
            async with httpx.AsyncClient() as client:
                # Get user info
                response = await client.get(
                    f"{self.api_url}/user.info?handles={username}",
                    timeout=self.timeout
                )
                
                if response.status_code == 200:
                    data = response.json()
                    
                    if data.get("status") == "OK" and data.get("result"):
                        user = data["result"][0]
                        
                        return {
                            "username": user.get("handle"),
                            "rating": user.get("rating", 0),
                            "max_rating": user.get("maxRating", 0),
                            "rank": user.get("rank", "Unrated"),
                            "contribution": user.get("contribution", 0),
                            "friend_of_count": user.get("friendOfCount", 0),
                            "platform": "Codeforces"
                        }
            
            return None
            
        except Exception as e:
            logger.error(f"Codeforces API error: {str(e)}")
            return None
    
    async def get_user_problems(self, username: str) -> Optional[Dict]:
        """Get user submission statistics"""
        
        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(
                    f"{self.api_url}/user.status?handle={username}&from=1&count=1000",
                    timeout=self.timeout
                )
                
                if response.status_code == 200:
                    data = response.json()
                    
                    if data.get("status") == "OK":
                        submissions = data.get("result", [])
                        
                        # Count AC and non-AC submissions
                        ac_count = sum(
                            1 for s in submissions 
                            if s.get("verdict") == "OK"
                        )
                        
                        return {
                            "accepted": ac_count,
                            "total": len(submissions),
                            "accuracy": round((ac_count / len(submissions) * 100), 2) if submissions else 0
                        }
            
            return None
            
        except Exception as e:
            logger.error(f"Codeforces submissions error: {str(e)}")
            return None


class HackerRankService(ExternalAPISBase):
    """HackerRank API Integration"""
    
    def __init__(self, api_key: Optional[str] = None):
        """Initialize HackerRank service"""
        self.api_url = "https://www.hackerrank.com/api/v1"
        self.api_key = api_key
        self.timeout = 10
    
    async def get_user_stats(self, username: str) -> Optional[Dict]:
        """
        Fetch user statistics from HackerRank
        
        Args:
            username: HackerRank username
            
        Returns:
            User statistics or None
        """
        
        try:
            headers = {}
            if self.api_key:
                headers["Authorization"] = f"Bearer {self.api_key}"
            
            async with httpx.AsyncClient() as client:
                response = await client.get(
                    f"{self.api_url}/users/{username}",
                    headers=headers,
                    timeout=self.timeout
                )
                
                if response.status_code == 200:
                    data = response.json()
                    
                    return {
                        "username": data.get("username"),
                        "name": data.get("name", "Unknown"),
                        "country": data.get("country", "Unknown"),
                        "badges": data.get("badges", []),
                        "problems_solved": data.get("problems_solved_count", 0),
                        "platform": "HackerRank"
                    }
            
            return None
            
        except Exception as e:
            logger.error(f"HackerRank API error: {str(e)}")
            return None
    
    async def get_user_problems(self, username: str) -> Optional[Dict]:
        """Get user's solved problems"""
        
        # HackerRank API requires authentication, returning placeholder
        try:
            # In production, this would use the actual API with proper authentication
            return {
                "problems_solved": 0,
                "skills": [],
                "platform": "HackerRank"
            }
            
        except Exception as e:
            logger.error(f"HackerRank problems error: {str(e)}")
            return None


class CompetitiveProgrammingAggregator:
    """Aggregate competitive programming statistics"""
    
    def __init__(self, leetcode_key: Optional[str] = None, 
                 codeforces_key: Optional[str] = None,
                 hackerrank_key: Optional[str] = None):
        """Initialize aggregator"""
        
        self.leetcode = LeetCodeService()
        self.codeforces = CodeforcesService()
        self.hackerrank = HackerRankService(hackerrank_key)
    
    async def get_all_stats(self, username: str) -> Dict[str, Any]:
        """Get stats from all platforms for given username"""
        
        stats = {
            "leetcode": None,
            "codeforces": None,
            "hackerrank": None
        }
        
        # Try each platform
        stats["leetcode"] = await self.leetcode.get_user_stats(username)
        stats["codeforces"] = await self.codeforces.get_user_stats(username)
        stats["hackerrank"] = await self.hackerrank.get_user_stats(username)
        
        # Filter out None values
        return {k: v for k, v in stats.items() if v is not None}
    
    def calculate_competitive_score(self, all_stats: Dict) -> Dict:
        """Calculate overall competitive programming score"""
        
        scores = []
        
        if all_stats.get("leetcode"):
            lc_score = min(
                (all_stats["leetcode"].get("problems_solved", {}).get("total", 0) / 3000) * 100,
                100
            )
            scores.append(("LeetCode", lc_score))
        
        if all_stats.get("codeforces"):
            cf_rating = all_stats["codeforces"].get("max_rating", 0)
            cf_score = min((cf_rating / 3000) * 100, 100)
            scores.append(("Codeforces", cf_score))
        
        if all_stats.get("hackerrank"):
            hr_score = min(
                (all_stats["hackerrank"].get("problems_solved", 0) / 500) * 100,
                100
            )
            scores.append(("HackerRank", hr_score))
        
        # Calculate weighted average
        if scores:
            total_score = sum(score for _, score in scores) / len(scores)
        else:
            total_score = 0
        
        return {
            "overall_score": round(total_score, 2),
            "platform_scores": scores,
            "competitive_level": self._determine_level(total_score)
        }
    
    def _determine_level(self, score: float) -> str:
        """Determine competitive programming level"""
        
        if score >= 80:
            return "Advanced/Expert"
        elif score >= 60:
            return "Intermediate"
        elif score >= 40:
            return "Beginner"
        else:
            return "Novice"


def get_external_api_service(platform: str, api_key: Optional[str] = None) -> ExternalAPISBase:
    """Factory function to get external API service"""
    
    if platform.lower() == "leetcode":
        return LeetCodeService()
    elif platform.lower() == "codeforces":
        return CodeforcesService()
    elif platform.lower() == "hackerrank":
        return HackerRankService(api_key)
    else:
        raise ValueError(f"Unknown platform: {platform}")
