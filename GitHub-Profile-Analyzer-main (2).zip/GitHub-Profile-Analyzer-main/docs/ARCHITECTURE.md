# DevInsight AI - Architecture & Design

Comprehensive technical architecture documentation.

---

## System Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                      Frontend (React/Next.js)                │
│  - Dashboard UI                                              │
│  - Analytics Visualization                                   │
│  - User Authentication                                       │
└──────────────────────┬──────────────────────────────────────┘
                       │ HTTPS
                       ▼
┌─────────────────────────────────────────────────────────────┐
│                    API Gateway / Load Balancer               │
│                    (Nginx / Cloud CDN)                       │
└──────────────────────┬──────────────────────────────────────┘
                       │
       ┌───────────────┼───────────────┐
       │               │               │
       ▼               ▼               ▼
┌────────────┐ ┌────────────┐ ┌────────────┐
│ FastAPI    │ │ FastAPI    │ │ FastAPI    │
│ Instance 1 │ │ Instance 2 │ │ Instance 3 │
│ (Async)    │ │ (Async)    │ │ (Async)    │
└─────┬──────┘ └─────┬──────┘ └─────┬──────┘
      │              │              │
      └──────────────┬──────────────┘
                     │
        ┌────────────┼────────────┐
        │            │            │
        ▼            ▼            ▼
   ┌──────────┐ ┌──────────┐ ┌──────────┐
   │ Cache    │ │Database  │ │External  │
   │(Redis)   │ │(Postgres)│ │APIs      │
   └──────────┘ └──────────┘ │GitHub    │
                             │OpenAI    │
                             │Gemini    │
                             └──────────┘
```

---

## Backend Architecture

### Technology Stack

**Framework:**
- FastAPI 0.115+ - Modern async web framework
- Pydantic 2.11+ - Data validation and serialization
- Uvicorn 0.34+ - ASGI server

**Data & Cache:**
- PostgreSQL - Primary data store (optional)
- Redis - Caching layer (optional)
- SQLAlchemy - ORM

**AI/ML:**
- OpenAI API - GPT-4 Turbo for insights
- Google Gemini - Alternative AI provider
- LangChain - AI/LLM orchestration (upcoming)

**External Integrations:**
- GitHub REST API v3
- LeetCode GraphQL API (upcoming)
- Codeforces API (upcoming)

---

### Layered Architecture

```
┌─────────────────────────────────────┐
│        API Layer (Routes)            │
│  /api/v1/analytics/*                │
│  /api/v1/insights/*                 │
│  /api/health/*                      │
└────────────────┬────────────────────┘
                 │
┌────────────────▼────────────────────┐
│    Service Layer (Business Logic)    │
│  - GitHub Service                   │
│  - Analytics Engine                 │
│  - AI Engine                        │
│  - Report Generator                 │
└────────────────┬────────────────────┘
                 │
┌────────────────▼────────────────────┐
│   Core Analytics & AI Modules        │
│  - Scorer (scoring engine)          │
│  - Contributor Analyzer             │
│  - Tech Stack Analyzer              │
│  - Summarizer (AI insights)         │
│  - Recommender                      │
└────────────────┬────────────────────┘
                 │
┌────────────────▼────────────────────┐
│    Integration Layer                 │
│  - GitHub API Client                │
│  - OpenAI Client                    │
│  - Gemini Client                    │
│  - External API Clients             │
└────────────────┬────────────────────┘
                 │
┌────────────────▼────────────────────┐
│   Infrastructure Layer               │
│  - Database (PostgreSQL)            │
│  - Cache (Redis)                    │
│  - Queue (optional)                 │
└─────────────────────────────────────┘
```

---

## Core Components

### 1. Analytics Engine (`core/analytics/scorer.py`)

**Responsibility:** Calculate developer metrics and scores

**Key Functions:**
- `calculate_developer_score()` - Overall score (0-100)
- `calculate_productivity_metrics()` - Activity and consistency
- `analyze_tech_stack()` - Technology breakdown
- `calculate_open_source_impact()` - Community influence

**Scoring Formula:**
```
Overall Score = 
  (Contribution Score × 0.25) +
  (Impact Score × 0.20) +
  (Consistency Score × 0.20) +
  (Diversity Score × 0.15) +
  (Collaboration Score × 0.20)
```

### 2. AI Engine (`core/ai/summarizer.py`)

**Responsibility:** Generate AI-powered insights

**Key Functions:**
- `generate_developer_summary()` - Profile summary (GPT-4)
- `generate_career_recommendations()` - Role suggestions
- `generate_strengths_and_weaknesses()` - Skill analysis
- `generate_improvement_suggestions()` - Actionable tips

**Features:**
- Fallback responses when AI APIs unavailable
- Prompt engineering for quality insights
- Multi-provider support (OpenAI, Gemini)

### 3. GitHub Service (`services/github_service.py`)

**Responsibility:** GitHub API integration

**Key Functions:**
- `get_profile()` - User profile data
- `get_repositories()` - Repository list with pagination
- `get_user_events()` - Public events
- `check_rate_limit()` - API rate limit status

**Features:**
- Automatic caching (1 hour)
- Rate limit handling
- Error recovery
- Pagination support

### 4. API Routes

**V1 Analytics Routes** (`api/v1/analytics.py`):
- `GET /profile/{username}` - Complete analysis
- `GET /score/{username}` - Quick score
- `GET /repositories/{username}` - Repository stats
- `GET /tech-stack/{username}` - Tech stack analysis

**V1 Insights Routes** (`api/v1/insights.py`):
- `GET /summary/{username}` - AI summary
- `GET /recommendations/{username}` - Career recommendations
- `GET /analysis/{username}` - Strengths/weaknesses
- `GET /improvements/{username}` - Improvement suggestions

**Health Routes** (`api/v1/health.py`):
- `GET /` - Health status
- `GET /ready` - Readiness probe
- `GET /live` - Liveness probe

---

## Data Flow

### Profile Analysis Flow

```
1. User Request
   ▼
2. GitHub Service (Fetch Profile + Repos)
   ├─ Check Cache
   ├─ Fetch from GitHub API
   └─ Cache Results
   ▼
3. Analytics Engine
   ├─ Calculate Metrics
   ├─ Compute Developer Score
   ├─ Analyze Tech Stack
   └─ Calculate Productivity
   ▼
4. AI Engine (if enabled)
   ├─ Generate Summary
   ├─ Generate Recommendations
   └─ Generate Insights
   ▼
5. Format Response
   ├─ Build AnalyticsResponse
   └─ Return to User
   ▼
6. Response
```

---

## Configuration Management

```python
# Centralized settings in app/config/settings.py
# Using Pydantic Settings for type-safe configuration

class Settings(BaseSettings):
    # Project settings
    PROJECT_NAME: str
    ENVIRONMENT: str
    DEBUG: bool
    
    # API settings
    API_PREFIX: str
    BACKEND_CORS_ORIGINS: list
    
    # GitHub API
    GITHUB_API_URL: str
    GITHUB_TOKEN: Optional[str]
    
    # Database & Cache
    DATABASE_URL: Optional[str]
    REDIS_URL: Optional[str]
    
    # AI Services
    OPENAI_API_KEY: Optional[str]
    GEMINI_API_KEY: Optional[str]
    
    # Security
    SECRET_KEY: str
    ALGORITHM: str
    
    class Config:
        env_file = ".env"
```

**Environment Priority:**
1. System environment variables
2. `.env` file
3. Default values in Settings class

---

## Error Handling

### Middleware-based Error Handler

```python
# Centralized in app/api/middleware/error_handler.py

def error_handler_middleware(exc: Exception):
    """
    Standardized error response format
    
    Returns:
    {
        "error": "Error type",
        "message": "Detailed message",
        "status_code": 500,
        "timestamp": "ISO 8601 timestamp"
    }
    """
```

### HTTP Status Codes Used

- `200` - Success
- `400` - Bad request (validation error)
- `404` - Resource not found
- `422` - Validation error (Pydantic)
- `429` - Rate limit exceeded
- `500` - Internal server error

---

## Caching Strategy

### Cache Layers

1. **Application Cache (Redis)**
   - Profile data: 1 hour TTL
   - Repository data: 1 hour TTL
   - Follower data: 2 hours TTL

2. **Browser Cache**
   - API responses: 5 minutes
   - Static assets: 1 hour

3. **CDN Cache** (Production)
   - Public endpoints: 10 minutes
   - Images: 24 hours

### Cache Keys
```
profile_{username}
repos_{username}
followers_{username}
```

---

## Security Considerations

### Current Implementation

- CORS protection
- Rate limiting (future)
- Input validation (Pydantic)
- Safe error messages (no stack traces)

### Future Security Enhancements

- JWT authentication
- API key validation
- Rate limiting per user
- Request signing
- Data encryption at rest
- Audit logging

---

## Scalability

### Horizontal Scaling

**Load Balancing:**
- Nginx/HAProxy for reverse proxy
- Health checks on `/api/health/ready`
- Connection pooling

**Database:**
- Connection pooling (via SQLAlchemy)
- Read replicas for analytics
- Sharding by username (future)

**Caching:**
- Redis Cluster for distributed cache
- Cache invalidation on updates

### Performance Optimizations

1. **Async/Await**
   - All I/O operations non-blocking
   - Efficient use of server resources

2. **Connection Pooling**
   - Database connection pool
   - GitHub API rate limit management

3. **Response Compression**
   - Gzip compression for responses
   - Minimal JSON payloads

---

## Monitoring & Observability

### Metrics to Track

- API response times (p50, p95, p99)
- Error rates by endpoint
- GitHub API rate limit usage
- Cache hit/miss ratios
- AI API latency

### Logging

```python
# Structured logging with Python logging
logger = logging.getLogger(__name__)
logger.info("message")
logger.error("error", exc_info=True)
```

**Log Levels:**
- DEBUG - Development debugging
- INFO - General information
- WARNING - Potential issues
- ERROR - Errors
- CRITICAL - Critical failures

---

## Deployment Architecture

### Docker Container

```dockerfile
FROM python:3.11-slim

WORKDIR /app

# Install dependencies
COPY requirements.txt .
RUN pip install -r requirements.txt

# Copy application
COPY . .

# Expose port
EXPOSE 8000

# Run application
CMD ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000"]
```

### Kubernetes Deployment

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: devinsight-api
spec:
  replicas: 3
  template:
    spec:
      containers:
      - name: api
        image: devinsight-api:latest
        ports:
        - containerPort: 8000
        livenessProbe:
          httpGet:
            path: /api/health/live
            port: 8000
        readinessProbe:
          httpGet:
            path: /api/health/ready
            port: 8000
```

---

## Future Architecture Enhancements

### Microservices (Phase 2)

```
API Gateway
    │
    ├─ Auth Service
    ├─ Analytics Service
    ├─ AI Service
    ├─ Notification Service
    └─ Reporting Service
```

### Event-Driven Architecture (Phase 3)

```
Events:
- profile.analyzed
- score.updated
- report.generated

Queue: Kafka / RabbitMQ
Processing: Celery / AWS Lambda
```

### Machine Learning (Phase 4)

```
- Career prediction models
- Skill recommendation engine
- Developer clustering
- Anomaly detection
```

---

## Technology Decisions & Rationale

| Technology | Why? |
|-----------|------|
| FastAPI | Modern, fast, built-in validation |
| Pydantic | Type-safe, excellent ecosystem |
| PostgreSQL | Reliable, scalable, mature |
| Redis | Fast caching, pub/sub support |
| OpenAI | SOTA AI for summaries & insights |
| GitHub API | Official, comprehensive, reliable |
| Docker | Consistent deployment, reproducible |
| Kubernetes | Production-grade orchestration |

---

## Database Schema (Future)

```sql
-- Users Table
CREATE TABLE users (
    id UUID PRIMARY KEY,
    github_username VARCHAR(255) UNIQUE,
    email VARCHAR(255),
    created_at TIMESTAMP,
    updated_at TIMESTAMP
);

-- Analyses Table
CREATE TABLE analyses (
    id UUID PRIMARY KEY,
    user_id UUID REFERENCES users(id),
    developer_score FLOAT,
    analysis_data JSONB,
    created_at TIMESTAMP
);

-- Reports Table
CREATE TABLE reports (
    id UUID PRIMARY KEY,
    user_id UUID REFERENCES users(id),
    report_type VARCHAR(50),
    content JSONB,
    created_at TIMESTAMP
);
```

---

## Conclusion

DevInsight AI is built with scalability, maintainability, and user experience in mind. The modular architecture allows for easy feature additions, and the async-first approach ensures efficient resource usage.

