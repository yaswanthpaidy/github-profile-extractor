# DevInsight AI - Deployment Guide

Comprehensive guide for deploying DevInsight AI to production.

---

## Pre-Deployment Checklist

- [ ] Environment variables configured
- [ ] API keys obtained (GitHub, OpenAI, Gemini)
- [ ] Database prepared (if using PostgreSQL)
- [ ] Redis configured (if using cache)
- [ ] Dependencies installed
- [ ] Tests passing locally
- [ ] Docker image built
- [ ] Domain name configured
- [ ] SSL certificate obtained

---

## Local Development Deployment

### Using Docker Compose

**1. Create docker-compose.yml**

```yaml
version: '3.8'

services:
  backend:
    build: ./backend
    ports:
      - "8000:8000"
    environment:
      - DEBUG=True
      - ENVIRONMENT=development
      - GITHUB_TOKEN=${GITHUB_TOKEN}
      - OPENAI_API_KEY=${OPENAI_API_KEY}
    depends_on:
      - redis
    volumes:
      - ./backend:/app

  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"

  postgres:
    image: postgres:15-alpine
    environment:
      POSTGRES_DB: devinsight
      POSTGRES_PASSWORD: ${DB_PASSWORD}
    ports:
      - "5432:5432"
    volumes:
      - postgres_data:/var/lib/postgresql/data

volumes:
  postgres_data:
```

**2. Start Services**

```bash
# Copy environment variables
cp backend/.env.example backend/.env

# Start all services
docker-compose up -d

# View logs
docker-compose logs -f backend
```

**3. Verify Deployment**

```bash
# Check API health
curl http://localhost:8000/api/health

# View API docs
open http://localhost:8000/api/docs
```

---

## Production Deployment

### Render Deployment

**1. Create render.yaml**

```yaml
services:
  - type: web
    name: devinsight-api
    env: python
    buildCommand: pip install -r requirements.txt
    startCommand: uvicorn app.main:app --host 0.0.0.0 --port $PORT
    envVars:
      - key: ENVIRONMENT
        value: production
      - key: DEBUG
        value: false
      - key: GITHUB_TOKEN
        scope: secret
      - key: OPENAI_API_KEY
        scope: secret
      - key: SECRET_KEY
        scope: secret
      - key: DATABASE_URL
        scope: secret
      - key: REDIS_URL
        scope: secret

  - type: postgresql
    name: devinsight-db
    version: '15'
    plan: free

  - type: redis
    name: devinsight-cache
    plan: free
```

**2. Deploy to Render**

```bash
# Push to GitHub
git push origin main

# Connect in Render dashboard:
# 1. Go to render.com
# 2. New → Web Service
# 3. Connect GitHub repo
# 4. Select render.yaml
# 5. Deploy
```

**3. Set Environment Variables**

In Render Dashboard:
- Environment → Environment Variables
- Add all secret keys

---

### Railway Deployment

**1. Install Railway CLI**

```bash
# macOS
brew install railway

# Windows
choco install railway

# Linux
curl -fsSL railway.app/install.sh | bash
```

**2. Deploy**

```bash
# Login
railway login

# Initialize project
railway init

# Deploy
railway up
```

**3. Configure Services**

```bash
# Add PostgreSQL
railway add postgresql

# Add Redis
railway add redis

# Set environment variables
railway variable add GITHUB_TOKEN=your_token
railway variable add OPENAI_API_KEY=your_key
```

---

### AWS Deployment

**Option 1: ECS (Elastic Container Service)**

```bash
# 1. Build and push Docker image
aws ecr get-login-password --region us-east-1 | \
  docker login --username AWS --password-stdin $AWS_ACCOUNT_ID.dkr.ecr.us-east-1.amazonaws.com

docker build -t devinsight-api .
docker tag devinsight-api:latest $AWS_ACCOUNT_ID.dkr.ecr.us-east-1.amazonaws.com/devinsight-api:latest
docker push $AWS_ACCOUNT_ID.dkr.ecr.us-east-1.amazonaws.com/devinsight-api:latest

# 2. Create ECS task definition (JSON)
# 3. Create ECS service
# 4. Configure load balancer
# 5. Setup auto-scaling
```

**Option 2: Lambda + API Gateway**

```bash
# Use Mangum for ASGI to Lambda adapter
pip install mangum

# Create lambda_handler.py
from mangum import Mangum
from app.main import app

handler = Mangum(app)

# Deploy with AWS SAM
sam package --output-template-file packaged.yaml
sam deploy --template-file packaged.yaml
```

---

### Kubernetes Deployment

**1. Create Kubernetes Manifests**

```yaml
# namespace.yaml
apiVersion: v1
kind: Namespace
metadata:
  name: devinsight

---
# deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: devinsight-api
  namespace: devinsight
spec:
  replicas: 3
  selector:
    matchLabels:
      app: devinsight-api
  template:
    metadata:
      labels:
        app: devinsight-api
    spec:
      containers:
      - name: api
        image: devinsight-api:latest
        ports:
        - containerPort: 8000
        env:
        - name: ENVIRONMENT
          value: "production"
        - name: GITHUB_TOKEN
          valueFrom:
            secretKeyRef:
              name: devinsight-secrets
              key: github-token
        resources:
          requests:
            memory: "256Mi"
            cpu: "250m"
          limits:
            memory: "512Mi"
            cpu: "500m"
        livenessProbe:
          httpGet:
            path: /api/health/live
            port: 8000
          initialDelaySeconds: 10
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /api/health/ready
            port: 8000
          initialDelaySeconds: 5
          periodSeconds: 5

---
# service.yaml
apiVersion: v1
kind: Service
metadata:
  name: devinsight-api
  namespace: devinsight
spec:
  type: LoadBalancer
  ports:
  - port: 80
    targetPort: 8000
  selector:
    app: devinsight-api

---
# hpa.yaml
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: devinsight-hpa
  namespace: devinsight
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: devinsight-api
  minReplicas: 3
  maxReplicas: 10
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
```

**2. Deploy to Kubernetes**

```bash
# Create namespace
kubectl create namespace devinsight

# Create secrets
kubectl create secret generic devinsight-secrets \
  --from-literal=github-token=$GITHUB_TOKEN \
  --from-literal=openai-key=$OPENAI_API_KEY \
  -n devinsight

# Deploy
kubectl apply -f k8s/

# Check status
kubectl get pods -n devinsight
kubectl get svc -n devinsight
```

---

## Database Setup

### PostgreSQL Migration (Future)

```bash
# Initialize database
alembic init migrations

# Create migration
alembic revision --autogenerate -m "Initial schema"

# Apply migration
alembic upgrade head
```

---

## SSL/TLS Configuration

### Let's Encrypt with Nginx

```nginx
server {
    listen 443 ssl http2;
    server_name api.devinsightai.com;

    ssl_certificate /etc/letsencrypt/live/api.devinsightai.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/api.devinsightai.com/privkey.pem;

    location / {
        proxy_pass http://localhost:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

### Auto-renewal with Certbot

```bash
certbot renew --quiet --no-eff-email --agree-tos
```

---

## Monitoring & Logging

### Sentry Error Tracking

```python
# app/main.py
import sentry_sdk

sentry_sdk.init(
    dsn=settings.SENTRY_DSN,
    environment=settings.ENVIRONMENT,
    traces_sample_rate=0.1
)
```

### CloudWatch Logs (AWS)

```python
import logging
import watchtower

logging.basicConfig(
    level=logging.INFO,
    handlers=[
        watchtower.CloudWatchLogHandler()
    ]
)
```

### Prometheus Metrics

```bash
pip install prometheus-client

# Add to main.py
from prometheus_fastapi_instrumentator import Instrumentator

Instrumentator().instrument(app).expose(app)
```

---

## Performance Tuning

### Gunicorn Configuration

```bash
gunicorn \
  --workers 4 \
  --worker-class uvicorn.workers.UvicornWorker \
  --worker-tmp-dir /dev/shm \
  --max-requests 1000 \
  --max-requests-jitter 50 \
  app.main:app
```

### Production Checklist

- [ ] DEBUG = False
- [ ] SECRET_KEY changed
- [ ] CORS origins restricted
- [ ] Rate limiting enabled
- [ ] Error tracking configured
- [ ] Logging configured
- [ ] Database backups scheduled
- [ ] Monitoring configured
- [ ] Health checks setup
- [ ] Auto-scaling configured

---

## Health Checks & Monitoring

### Endpoint Monitoring

```bash
# Periodic health check
curl -f https://api.devinsightai.com/api/health/ || exit 1

# With alerting
watch -n 60 'curl -f https://api.devinsightai.com/api/health/'
```

---

## Rollback Strategy

### Blue-Green Deployment

```bash
# Deploy to green
docker pull devinsight-api:v1.1.0
docker tag devinsight-api:v1.1.0 devinsight-api:green

# Test green
curl http://green.devinsightai.com/api/health

# Switch traffic
nginx_config_set_upstream green

# Keep blue as fallback
```

---

## Disaster Recovery

### Backup Strategy

```bash
# Daily database backup
pg_dump devinsight | gzip > backup_$(date +%Y%m%d).sql.gz

# Upload to S3
aws s3 cp backup_*.sql.gz s3://devinsight-backups/

# Test restore
gunzip < backup_20240101.sql.gz | psql devinsight
```

---

## CI/CD Pipeline

### GitHub Actions Workflow

```yaml
name: Deploy to Production

on:
  push:
    branches: [main]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: Run tests
        run: |
          cd backend
          pip install -r requirements.txt
          pytest

  deploy:
    needs: test
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: Deploy to Render
        run: |
          curl https://api.render.com/deploy/srv/${{ secrets.RENDER_SERVICE_ID }}?key=${{ secrets.RENDER_API_KEY }}
```

---

## Costs Estimation

| Service | Free Tier | Paid Starting |
|---------|-----------|---------------|
| Render | Web Service | $12/month |
| Railway | $5/month | $5+ /month |
| AWS EC2 | 12 months free | $10+/month |
| AWS RDS | 12 months free | $30+/month |
| GitHub Actions | 2000 min/month | $0.25/min |

---

## Support & Troubleshooting

### Common Issues

**Issue: 502 Bad Gateway**
```bash
# Check backend logs
docker logs backend

# Restart service
docker restart backend
```

**Issue: Slow API Response**
```bash
# Check cache
redis-cli ping

# Check database connections
SELECT count(*) FROM pg_stat_activity;
```

**Issue: Rate Limited by GitHub**
```bash
# Check rate limit
curl https://api.github.com/rate_limit

# Use GitHub token in requests
GITHUB_TOKEN=... python script.py
```

---

## Next Steps

1. Choose deployment platform (Render/Railway/AWS/K8s)
2. Set up environment variables
3. Configure database (if needed)
4. Setup monitoring and logging
5. Configure CI/CD pipeline
6. Test thoroughly before production
7. Plan backup and disaster recovery
8. Monitor costs

---

## Additional Resources

- [FastAPI Deployment Docs](https://fastapi.tiangolo.com/deployment/)
- [Render Docs](https://render.com/docs)
- [Railway Docs](https://docs.railway.app/)
- [AWS Docs](https://docs.aws.amazon.com/)
- [Kubernetes Docs](https://kubernetes.io/docs/)

