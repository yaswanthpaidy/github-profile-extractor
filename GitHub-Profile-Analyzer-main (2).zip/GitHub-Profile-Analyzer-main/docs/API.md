# DevInsight AI - API Documentation

Complete API reference for DevInsight AI endpoints.

## Base URL

```
http://localhost:8000/api/v1
```

## Authentication

Currently, API endpoints are public. Authentication will be added in future releases.

---

## Analytics Endpoints

### Get Complete Profile Analysis

**GET** `/analytics/profile/{username}`

Retrieve comprehensive developer analytics including scores, metrics, and AI insights.

**Parameters:**
- `username` (path, required): GitHub username
- `include_ai` (query, optional): Include AI insights (default: true)

**Example:**
```bash
curl -X GET "http://localhost:8000/api/v1/analytics/profile/torvalds?include_ai=true"
```

**Response:**
```json
{
  "profile": {
    "username": "torvalds",
    "name": "Linus Torvalds",
    "avatar_url": "...",
    "followers": 200000,
    "public_repos": 50,
    ...
  },
  "developer_score": {
    "overall_score": 98.5,
    "contribution_score": 99,
    "impact_score": 99,
    "consistency_score": 95,
    "diversity_score": 88,
    "collaboration_score": 92,
    "level": "expert"
  },
  "productivity_metrics": {...},
  "tech_stack": {...},
  "ai_insights": {...},
  "top_repositories": [...],
  "analysis_timestamp": "2024-01-01T12:00:00"
}
```

---

### Get Developer Score Only

**GET** `/analytics/score/{username}`

Quick endpoint to get just the developer score (0-100).

**Example:**
```bash
curl -X GET "http://localhost:8000/api/v1/analytics/score/johndoe"
```

**Response:**
```json
{
  "overall_score": 82.5,
  "contribution_score": 85,
  "impact_score": 75,
  "consistency_score": 88,
  "diversity_score": 80,
  "collaboration_score": 78,
  "level": "advanced"
}
```

---

### Get Repositories

**GET** `/analytics/repositories/{username}`

Get detailed statistics about user's repositories.

**Parameters:**
- `username` (path, required): GitHub username
- `limit` (query, optional): Number of repos (1-100, default: 10)

**Example:**
```bash
curl -X GET "http://localhost:8000/api/v1/analytics/repositories/johndoe?limit=20"
```

**Response:**
```json
[
  {
    "name": "awesome-project",
    "description": "An awesome project",
    "language": "Python",
    "stars": 150,
    "forks": 30,
    "watchers": 45,
    "open_issues": 5,
    "created_at": "2020-01-01T00:00:00Z",
    "updated_at": "2024-01-15T12:00:00Z",
    "url": "https://github.com/johndoe/awesome-project"
  },
  ...
]
```

---

### Get Tech Stack

**GET** `/analytics/tech-stack/{username}`

Analyze the technology stack used by a developer.

**Example:**
```bash
curl -X GET "http://localhost:8000/api/v1/analytics/tech-stack/johndoe"
```

**Response:**
```json
{
  "primary_languages": ["Python", "JavaScript", "TypeScript"],
  "frameworks": ["FastAPI", "React", "Django"],
  "tools": ["Docker", "Kubernetes", "Git"],
  "databases": ["PostgreSQL", "MongoDB"],
  "cloud_platforms": ["AWS", "GCP"]
}
```

---

## Insights Endpoints

### Get AI Summary

**GET** `/insights/summary/{username}`

Get AI-generated developer summary powered by GPT-4.

**Example:**
```bash
curl -X GET "http://localhost:8000/api/v1/insights/summary/johndoe"
```

**Response:**
```json
{
  "summary": "John is an experienced full-stack developer with strong backend expertise...",
  "strengths": [
    "Strong Python skills",
    "Good open-source contributor",
    "Effective team player"
  ],
  "weaknesses": [
    "Limited cloud infrastructure experience",
    "Could improve documentation"
  ],
  "recommendations": [
    "Contribute to enterprise projects",
    "Learn Kubernetes",
    "Improve project documentation"
  ],
  "career_recommendations": {
    "roles": ["Senior Engineer", "Tech Lead"],
    "industries": ["FinTech", "SaaS"]
  },
  "generated_at": "2024-01-01T12:00:00Z"
}
```

---

### Get Career Recommendations

**GET** `/insights/recommendations/{username}`

Get personalized career recommendations based on GitHub profile.

**Example:**
```bash
curl -X GET "http://localhost:8000/api/v1/insights/recommendations/johndoe"
```

**Response:**
```json
{
  "recommendation": "Based on your profile strength, recommended roles include...",
  "roles": [
    "Senior Software Engineer",
    "Tech Lead",
    "Solution Architect"
  ],
  "industries": [
    "FinTech",
    "SaaS",
    "Enterprise Software"
  ],
  "salary_range": {
    "min": 150000,
    "max": 250000,
    "currency": "USD"
  }
}
```

---

### Get Strengths & Weaknesses Analysis

**GET** `/insights/analysis/{username}`

Detailed analysis of developer strengths and areas for improvement.

**Example:**
```bash
curl -X GET "http://localhost:8000/api/v1/insights/analysis/johndoe"
```

**Response:**
```json
{
  "strengths": [
    "Strong backend development skills",
    "Good at system design",
    "Active open-source contributor",
    "Strong Python expertise",
    "Effective leadership experience"
  ],
  "weaknesses": [
    "Limited frontend experience",
    "Could improve documentation quality",
    "Limited cloud architecture knowledge",
    "Could engage more with community",
    "Build more impactful projects"
  ]
}
```

---

### Get Improvement Suggestions

**GET** `/insights/improvements/{username}`

Specific, actionable suggestions to improve developer brand.

**Example:**
```bash
curl -X GET "http://localhost:8000/api/v1/insights/improvements/johndoe"
```

**Response:**
```json
{
  "username": "johndoe",
  "suggestions": [
    "Improve README documentation for key projects",
    "Contribute to popular open-source projects",
    "Share technical insights through blog posts",
    "Engage more in community discussions",
    "Build a portfolio project showcasing your strengths"
  ],
  "generated_at": "2024-01-01T12:00:00Z"
}
```

---

## Health & Status Endpoints

### Health Check

**GET** `/health/`

Check API health status.

**Response:**
```json
{
  "status": "healthy",
  "version": "1.0.0",
  "environment": "production",
  "services": {
    "api": "healthy",
    "github": "operational",
    "cache": "operational"
  },
  "timestamp": "2024-01-01T12:00:00Z"
}
```

---

### Readiness Check (Kubernetes)

**GET** `/health/ready`

Check if API is ready to accept traffic.

**Response:**
```json
{
  "status": "ready"
}
```

---

### Liveness Check (Kubernetes)

**GET** `/health/live`

Check if API is alive.

**Response:**
```json
{
  "status": "alive"
}
```

---

## Error Responses

All endpoints return standardized error responses:

```json
{
  "error": "Invalid GitHub Username",
  "message": "The provided GitHub username does not exist",
  "status_code": 404,
  "timestamp": "2024-01-01T12:00:00Z"
}
```

### Common Status Codes
- `200` - Success
- `400` - Bad Request
- `404` - Not Found
- `422` - Validation Error
- `429` - Rate Limited
- `500` - Internal Server Error

---

## Rate Limiting

API requests are rate limited to 100 requests per hour per IP address.

Rate limit headers are included in responses:
```
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 95
X-RateLimit-Reset: 1704110400
```

---

## Caching

Responses are cached based on endpoint:
- Profile data: 1 hour
- Repository data: 1 hour
- Follower data: 2 hours
- AI insights: Not cached (fresh generation)

---

## Best Practices

1. **Always include error handling** - Implement try/catch for API calls
2. **Implement caching** - Cache responses on the client side
3. **Use pagination** - For large datasets
4. **Monitor rate limits** - Check X-RateLimit headers
5. **Cache management** - Clear cache when updating user data

---

## SDK/Client Libraries

Coming soon:
- Python SDK
- JavaScript/TypeScript SDK
- Go SDK
- Java SDK

---

## Changelog

### v1.0.0 (Current)
- Initial release
- Core analytics endpoints
- AI insights endpoints
- Health check endpoints

---

## Support

For API issues or questions:
- Email: api-support@devinsightai.com
- GitHub Issues: [Report a bug](https://github.com/devinsight-ai/issues)
- Discord: [Join community](https://discord.gg/devinsight)

